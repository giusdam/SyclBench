var classcl_1_1sycl_1_1property_1_1buffer_1_1use__host__ptr =
[
    [ "use_host_ptr", "classcl_1_1sycl_1_1property_1_1buffer_1_1use__host__ptr.html#a8090e94f0c91e14dc435d5326cd0c360", null ]
];