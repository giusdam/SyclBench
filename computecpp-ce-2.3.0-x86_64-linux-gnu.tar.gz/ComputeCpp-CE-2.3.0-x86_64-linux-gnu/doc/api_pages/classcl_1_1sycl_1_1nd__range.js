var classcl_1_1sycl_1_1nd__range =
[
    [ "nd_range", "classcl_1_1sycl_1_1nd__range.html#a79ee30bf7879518ed4de381256c29fa3", null ],
    [ "nd_range", "classcl_1_1sycl_1_1nd__range.html#a92b969ce9f165c180b796c7423da02d1", null ],
    [ "COMPUTECPP_DEPRECATED_API", "classcl_1_1sycl_1_1nd__range.html#aeac08d5627e2d0ebde3a9d074f1452e4", null ],
    [ "COMPUTECPP_DEPRECATED_API", "classcl_1_1sycl_1_1nd__range.html#a1bc48b08c9ed9383a98bdada3590ad11", null ],
    [ "COMPUTECPP_DEPRECATED_API", "classcl_1_1sycl_1_1nd__range.html#a7e446a685f1c17333387e5b487b27242", null ],
    [ "get_global_range", "classcl_1_1sycl_1_1nd__range.html#a89ede6ba709203cb70b8707a010809a1", null ],
    [ "get_group_range", "classcl_1_1sycl_1_1nd__range.html#a3dd923212ac3218e45c11dd25f6b544f", null ],
    [ "get_local_range", "classcl_1_1sycl_1_1nd__range.html#a5e89c38806c1b896aa9e1e364b37eaa1", null ],
    [ "get_offset", "classcl_1_1sycl_1_1nd__range.html#a984fcb47fd7d6cd6d127ed6e599ad381", null ],
    [ "operator!=", "classcl_1_1sycl_1_1nd__range.html#a5b8f288e2c4aacd6d1ccd418ea1cf60f", null ],
    [ "operator==", "classcl_1_1sycl_1_1nd__range.html#a36de55c8b7a461894dfac52db9473bb0", null ]
];