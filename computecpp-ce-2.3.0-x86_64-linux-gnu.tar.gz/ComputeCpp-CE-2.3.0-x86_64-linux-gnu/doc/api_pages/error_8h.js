var error_8h =
[
    [ "exception", "classcl_1_1sycl_1_1exception.html", "classcl_1_1sycl_1_1exception" ],
    [ "exception_list", "classcl_1_1sycl_1_1exception__list.html", "classcl_1_1sycl_1_1exception__list" ],
    [ "runtime_error", "classcl_1_1sycl_1_1runtime__error.html", null ],
    [ "kernel_error", "classcl_1_1sycl_1_1kernel__error.html", null ],
    [ "accessor_error", "classcl_1_1sycl_1_1accessor__error.html", null ],
    [ "nd_range_error", "classcl_1_1sycl_1_1nd__range__error.html", null ],
    [ "event_error", "classcl_1_1sycl_1_1event__error.html", null ],
    [ "invalid_parameter_error", "classcl_1_1sycl_1_1invalid__parameter__error.html", null ],
    [ "device_error", "classcl_1_1sycl_1_1device__error.html", null ],
    [ "compile_program_error", "classcl_1_1sycl_1_1compile__program__error.html", null ],
    [ "link_program_error", "classcl_1_1sycl_1_1link__program__error.html", null ],
    [ "invalid_object_error", "classcl_1_1sycl_1_1invalid__object__error.html", null ],
    [ "memory_allocation_error", "classcl_1_1sycl_1_1memory__allocation__error.html", null ],
    [ "platform_error", "classcl_1_1sycl_1_1platform__error.html", null ],
    [ "profiling_error", "classcl_1_1sycl_1_1profiling__error.html", null ],
    [ "feature_not_supported", "classcl_1_1sycl_1_1feature__not__supported.html", null ],
    [ "async_handler", "error_8h.html#ad5040b06655698bb2fe2f6714ef975e7", null ],
    [ "exception_ptr_class", "error_8h.html#a2142f5990bff9e140a51aac753244d37", null ]
];