var classcl_1_1sycl_1_1experimental_1_1usm__allocator =
[
    [ "rebind", "structcl_1_1sycl_1_1experimental_1_1usm__allocator_1_1rebind.html", "structcl_1_1sycl_1_1experimental_1_1usm__allocator_1_1rebind" ],
    [ "const_pointer", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a46281106e3b55577da37139780ac2bd8", null ],
    [ "const_reference", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a32a4a14311bf7e897def7f9031d50eb4", null ],
    [ "pointer", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#ad8cde14c816f8b704910ab190ef32675", null ],
    [ "reference", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a0bef36baba6b6b7b65878a639c1bd15d", null ],
    [ "value_type", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a3ead9742d45549218954a93101410472", null ],
    [ "usm_allocator", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#af277db322fb829fb910038942a2d4bb5", null ],
    [ "usm_allocator", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a72d7b5ce6459fe1568c72aa3a24e3433", null ],
    [ "usm_allocator", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a2bac320b5d3da571ffd543ae1a70e61a", null ],
    [ "usm_allocator", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a48d707687c763b33e936952428136e59", null ],
    [ "usm_allocator", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#abe407b104d5db0379dc2e15bbf24f698", null ],
    [ "address", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#aa4f40ca6303de4b8f77d5d1523acb0c7", null ],
    [ "address", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#aa4f40ca6303de4b8f77d5d1523acb0c7", null ],
    [ "address", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a49ec084b0cb92b35df547ef6187125d7", null ],
    [ "address", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a49ec084b0cb92b35df547ef6187125d7", null ],
    [ "allocate", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a8231af823835bd8ab85827097cedb325", null ],
    [ "construct", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a3967debb0860298b432e196550e14528", null ],
    [ "construct", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a3967debb0860298b432e196550e14528", null ],
    [ "deallocate", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a58c553ee9cc61b7d854cad9321cf6d08", null ],
    [ "destroy", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a91366377081d70688d80dbc8a8b748b6", null ],
    [ "destroy", "classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a91366377081d70688d80dbc8a8b748b6", null ]
];