var searchData=
[
  ['cgh',['cgh',['../classcl_1_1sycl_1_1codeplay_1_1host__handler.html#a4b5f3d2607d78c527e2cd1d3b34999d2',1,'cl::sycl::codeplay::host_handler']]],
  ['computecpp_5fconvert_5fattr',['COMPUTECPP_CONVERT_ATTR',['../namespacecl_1_1sycl.html#a9494691180cc902df8e7398750aaa48b',1,'cl::sycl']]],
  ['computecpp_5fconvert_5fattr_5fplaceholder',['COMPUTECPP_CONVERT_ATTR_PLACEHOLDER',['../namespacecl_1_1sycl.html#a2b5cda090db3726ab857425386f1b93e',1,'cl::sycl']]],
  ['computecpp_5fconvert_5fattr_5fsampler',['COMPUTECPP_CONVERT_ATTR_SAMPLER',['../namespacecl_1_1sycl.html#a23e8d29c2f84612c80f0eae934c12cac',1,'cl::sycl']]],
  ['computecpp_5fprivate_5fmemory_5fattr',['COMPUTECPP_PRIVATE_MEMORY_ATTR',['../namespacecl_1_1sycl.html#ae4004ef4686def03a08d9d64cabda9a8',1,'cl::sycl']]],
  ['copybounds',['copyBounds',['../classcl_1_1sycl_1_1nd__item.html#a47f452cc96d0389d39e94de669957151',1,'cl::sycl::nd_item::copyBounds()'],['../classcl_1_1sycl_1_1nd__item.html#a45fe6fb1986e6cd20f3c9a5402a83b58',1,'cl::sycl::nd_item::copyBounds()'],['../classcl_1_1sycl_1_1nd__item.html#a79b3ba7dacb51b729553d464bb19be24',1,'cl::sycl::nd_item::copyBounds()'],['../classcl_1_1sycl_1_1nd__item.html#a27b469756a60c5391d4d392b22d49a8e',1,'cl::sycl::nd_item::copyBounds()']]]
];
