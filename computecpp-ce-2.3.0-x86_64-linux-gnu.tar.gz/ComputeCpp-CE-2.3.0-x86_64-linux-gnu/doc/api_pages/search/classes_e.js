var searchData=
[
  ['param_5ftraits',['param_traits',['../structcl_1_1sycl_1_1info_1_1param__traits.html',1,'cl::sycl::info']]],
  ['platform',['platform',['../classcl_1_1sycl_1_1platform.html',1,'cl::sycl']]],
  ['platform_5ferror',['platform_error',['../classcl_1_1sycl_1_1platform__error.html',1,'cl::sycl']]],
  ['precision_5fmanipulator',['precision_manipulator',['../classcl_1_1sycl_1_1precision__manipulator.html',1,'cl::sycl']]],
  ['private_5fmemory',['private_memory',['../classcl_1_1sycl_1_1private__memory.html',1,'cl::sycl']]],
  ['profiling_5ferror',['profiling_error',['../classcl_1_1sycl_1_1profiling__error.html',1,'cl::sycl']]],
  ['profiling_5fzone',['profiling_zone',['../classcl_1_1sycl_1_1codeplay_1_1profiling_1_1profiling__zone.html',1,'cl::sycl::codeplay::profiling']]],
  ['program',['program',['../classcl_1_1sycl_1_1program.html',1,'cl::sycl']]],
  ['property_5flist',['property_list',['../classcl_1_1sycl_1_1property__list.html',1,'cl::sycl']]]
];
