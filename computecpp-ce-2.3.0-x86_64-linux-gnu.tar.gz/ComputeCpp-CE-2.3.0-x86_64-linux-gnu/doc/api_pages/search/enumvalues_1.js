var searchData=
[
  ['bgra',['bgra',['../namespacecl_1_1sycl.html#a8557ea72c6739001cf30a301567cf3dfa657c0fdc8e544dcb7153dcf613e04e2d',1,'cl::sycl']]],
  ['built_5fin_5fkernels',['built_in_kernels',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5accba6884a1618c6371e7aecc2bc3092d',1,'cl::sycl::info']]]
];
