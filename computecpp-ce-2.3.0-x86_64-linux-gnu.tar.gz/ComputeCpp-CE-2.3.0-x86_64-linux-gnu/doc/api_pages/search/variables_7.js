var searchData=
[
  ['hex',['hex',['../namespacecl_1_1sycl.html#a2e59955a893c2a9730cc7eb56d835b60',1,'cl::sycl']]],
  ['hexfloat',['hexfloat',['../namespacecl_1_1sycl.html#a430d6deabe5b26e5017faee17c6907f6',1,'cl::sycl']]]
];
