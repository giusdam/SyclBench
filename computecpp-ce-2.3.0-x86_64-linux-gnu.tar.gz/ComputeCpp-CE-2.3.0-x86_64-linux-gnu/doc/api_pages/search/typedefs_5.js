var searchData=
[
  ['float16',['float16',['../namespacecl_1_1sycl.html#a41ccef129e7a94cc96bbbc65042a2886',1,'cl::sycl']]],
  ['float2',['float2',['../namespacecl_1_1sycl.html#a4ee561318832d458cbe5ff8fbd5124ca',1,'cl::sycl']]],
  ['float3',['float3',['../namespacecl_1_1sycl.html#a4c8722dd91f479ce1bb6d5f87de78a27',1,'cl::sycl']]],
  ['float4',['float4',['../namespacecl_1_1sycl.html#ad6bac498bc2f259054b9e1bfc0d4736a',1,'cl::sycl']]],
  ['float8',['float8',['../namespacecl_1_1sycl.html#acdd4e66f1f3b93a13ea2e280e915fb13',1,'cl::sycl']]],
  ['function_5fclass',['function_class',['../namespacecl_1_1sycl.html#a7550bccaabf1f69b87c288f8f69dc11e',1,'cl::sycl']]]
];
