var searchData=
[
  ['device',['device',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5',1,'cl::sycl::info']]],
  ['device_5ftype',['device_type',['../namespacecl_1_1sycl_1_1info.html#a839771ab6b37e25ae67d5c8a2d4d97f8',1,'cl::sycl::info']]]
];
