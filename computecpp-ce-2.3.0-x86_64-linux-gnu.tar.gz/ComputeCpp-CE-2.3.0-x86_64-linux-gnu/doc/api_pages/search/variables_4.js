var searchData=
[
  ['endl',['endl',['../namespacecl_1_1sycl.html#a11b2262e2ead522b358cd14bd811ed6b',1,'cl::sycl']]]
];
