var searchData=
[
  ['image_5fchannel_5forder',['image_channel_order',['../namespacecl_1_1sycl.html#a8557ea72c6739001cf30a301567cf3df',1,'cl::sycl']]],
  ['image_5fchannel_5ftype',['image_channel_type',['../namespacecl_1_1sycl.html#a78b713c5436596506d5232e591a3b7ae',1,'cl::sycl']]]
];
