var searchData=
[
  ['device_5fqueue_5fproperties',['device_queue_properties',['../namespacecl_1_1sycl_1_1info.html#abae660ab9e55f797d6a8a02e325f5103',1,'cl::sycl::info']]],
  ['difference_5ftype',['difference_type',['../classcl_1_1sycl_1_1multi__ptr.html#a9ca2294c3e75523fa8e8dbf9367b2374',1,'cl::sycl::multi_ptr::difference_type()'],['../classcl_1_1sycl_1_1multi__ptr_3_01void_00_01asp_01_4.html#a38d62c221c28b9741963e31fb78a4d1a',1,'cl::sycl::multi_ptr&lt; void, asp &gt;::difference_type()'],['../classcl_1_1sycl_1_1multi__ptr_3_01const_01void_00_01asp_01_4.html#a76a8ebfeba33deb55451d55a40cd8518',1,'cl::sycl::multi_ptr&lt; const void, asp &gt;::difference_type()']]],
  ['double16',['double16',['../namespacecl_1_1sycl.html#a26158b645f3db1b2f631be7ab32382b1',1,'cl::sycl']]],
  ['double2',['double2',['../namespacecl_1_1sycl.html#adb0535e31c78aa8fd3236ca2d3c96042',1,'cl::sycl']]],
  ['double3',['double3',['../namespacecl_1_1sycl.html#a89da2ee2d019ada0e89416ce55950808',1,'cl::sycl']]],
  ['double4',['double4',['../namespacecl_1_1sycl.html#a4a1bbcbd91bc345f31a9a21bc18b55f2',1,'cl::sycl']]],
  ['double8',['double8',['../namespacecl_1_1sycl.html#aeca6ace4036380de82d4b74c07151459',1,'cl::sycl']]]
];
