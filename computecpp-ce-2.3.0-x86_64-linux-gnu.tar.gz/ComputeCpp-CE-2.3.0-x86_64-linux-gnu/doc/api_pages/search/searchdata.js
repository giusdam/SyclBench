var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxyz~",
  1: "abcdefghiklmnopqrsuv",
  2: "c",
  3: "abcdefghiklmopqrstuv",
  4: "abcdefghiklmnopqrstuw~",
  5: "abcdefghiklmnorswxyz",
  6: "abcdefghilmnoprsuvw",
  7: "abcdefghiklmprstw",
  8: "abcdefghilmnopqrstuvw",
  9: "amo",
  10: "_cs",
  11: "cdt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Pages"
};

