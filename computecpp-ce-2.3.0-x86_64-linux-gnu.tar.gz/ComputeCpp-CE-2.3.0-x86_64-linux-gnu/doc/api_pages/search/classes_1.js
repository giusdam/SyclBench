var searchData=
[
  ['buffer',['buffer',['../classcl_1_1sycl_1_1buffer.html',1,'cl::sycl']]],
  ['buffer_3c_20const_20t_2c_20dimensions_2c_20allocatort_20_3e',['buffer&lt; const T, dimensions, AllocatorT &gt;',['../classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html',1,'cl::sycl']]]
];
