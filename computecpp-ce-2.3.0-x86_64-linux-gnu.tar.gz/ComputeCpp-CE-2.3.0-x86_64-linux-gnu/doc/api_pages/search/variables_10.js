var searchData=
[
  ['w',['w',['../structcl_1_1sycl_1_1elem.html#a391e19e48ff05630f1f1fdd0b49e08b3',1,'cl::sycl::elem']]]
];
