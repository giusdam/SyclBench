var searchData=
[
  ['maximum',['maximum',['../structcl_1_1sycl_1_1experimental_1_1maximum.html',1,'cl::sycl::experimental']]],
  ['maximum_3c_20void_20_3e',['maximum&lt; void &gt;',['../structcl_1_1sycl_1_1experimental_1_1maximum_3_01void_01_4.html',1,'cl::sycl::experimental']]],
  ['memory_5fallocation_5ferror',['memory_allocation_error',['../classcl_1_1sycl_1_1memory__allocation__error.html',1,'cl::sycl']]],
  ['minimum',['minimum',['../structcl_1_1sycl_1_1experimental_1_1minimum.html',1,'cl::sycl::experimental']]],
  ['minimum_3c_20void_20_3e',['minimum&lt; void &gt;',['../structcl_1_1sycl_1_1experimental_1_1minimum_3_01void_01_4.html',1,'cl::sycl::experimental']]],
  ['multi_5fptr',['multi_ptr',['../classcl_1_1sycl_1_1multi__ptr.html',1,'cl::sycl']]],
  ['multi_5fptr_3c_20const_20void_2c_20asp_20_3e',['multi_ptr&lt; const void, asp &gt;',['../classcl_1_1sycl_1_1multi__ptr_3_01const_01void_00_01asp_01_4.html',1,'cl::sycl']]],
  ['multi_5fptr_3c_20datat_2c_20access_3a_3aaddress_5fspace_3a_3asubgroup_5flocal_5fspace_20_3e',['multi_ptr&lt; dataT, access::address_space::subgroup_local_space &gt;',['../classcl_1_1sycl_1_1multi__ptr.html',1,'cl::sycl']]],
  ['multi_5fptr_3c_20void_2c_20asp_20_3e',['multi_ptr&lt; void, asp &gt;',['../classcl_1_1sycl_1_1multi__ptr_3_01void_00_01asp_01_4.html',1,'cl::sycl']]]
];
