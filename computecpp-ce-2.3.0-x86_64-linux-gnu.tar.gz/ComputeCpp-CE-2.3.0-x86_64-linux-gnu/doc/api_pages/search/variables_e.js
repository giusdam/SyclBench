var searchData=
[
  ['r',['r',['../structcl_1_1sycl_1_1elem.html#aba79f56a8bd59d72ea49137d61c0581e',1,'cl::sycl::elem']]]
];
