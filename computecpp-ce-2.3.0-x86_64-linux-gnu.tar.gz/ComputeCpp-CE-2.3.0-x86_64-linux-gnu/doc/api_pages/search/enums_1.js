var searchData=
[
  ['backend',['backend',['../namespacecl_1_1sycl.html#a571d7124814717169c43cc12bde9ca30',1,'cl::sycl']]]
];
