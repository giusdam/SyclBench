var searchData=
[
  ['kernel',['kernel',['../namespacecl_1_1sycl_1_1info.html#a9845a480a36d09200c5355a775fc1fa1',1,'cl::sycl::info']]],
  ['kernel_5fsub_5fgroup',['kernel_sub_group',['../namespacecl_1_1sycl_1_1info.html#aaee38a765a8d99422ac3d2bbd4a79b8e',1,'cl::sycl::info']]],
  ['kernel_5fwork_5fgroup',['kernel_work_group',['../namespacecl_1_1sycl_1_1info.html#a592a8baeff484e312c7f5ce6192a6ccf',1,'cl::sycl::info']]]
];
