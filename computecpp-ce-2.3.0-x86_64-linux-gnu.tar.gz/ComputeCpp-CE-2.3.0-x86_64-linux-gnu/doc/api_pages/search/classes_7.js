var searchData=
[
  ['h_5fitem',['h_item',['../classcl_1_1sycl_1_1h__item.html',1,'cl::sycl']]],
  ['half',['half',['../classcl_1_1sycl_1_1half.html',1,'cl::sycl']]],
  ['handler',['handler',['../classcl_1_1sycl_1_1codeplay_1_1handler.html',1,'cl::sycl::codeplay']]],
  ['handler',['handler',['../classcl_1_1sycl_1_1handler.html',1,'cl::sycl']]],
  ['hash_3c_20cl_3a_3asycl_3a_3aaccessor_3c_20elemt_2c_20kdims_2c_20kmode_2c_20ktarget_2c_20isplaceholder_20_3e_20_3e',['hash&lt; cl::sycl::accessor&lt; elemT, kDims, kMode, kTarget, isPlaceholder &gt; &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1accessor_3_01elem_t_00_01k_dims_00_01k_mode_00_01k_target_00_01is_placeholder_01_4_01_4.html',1,'std']]],
  ['hash_3c_20cl_3a_3asycl_3a_3abuffer_3c_20t_2c_20dimensions_2c_20allocatort_20_3e_20_3e',['hash&lt; cl::sycl::buffer&lt; T, dimensions, AllocatorT &gt; &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01_allocator_t_01_4_01_4.html',1,'std']]],
  ['hash_3c_20cl_3a_3asycl_3a_3acontext_20_3e',['hash&lt; cl::sycl::context &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1context_01_4.html',1,'std']]],
  ['hash_3c_20cl_3a_3asycl_3a_3adevice_20_3e',['hash&lt; cl::sycl::device &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1device_01_4.html',1,'std']]],
  ['hash_3c_20cl_3a_3asycl_3a_3aevent_20_3e',['hash&lt; cl::sycl::event &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1event_01_4.html',1,'std']]],
  ['hash_3c_20cl_3a_3asycl_3a_3aimage_3c_20kdimensions_2c_20allocatort_20_3e_20_3e',['hash&lt; cl::sycl::image&lt; kDimensions, AllocatorT &gt; &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1image_3_01k_dimensions_00_01_allocator_t_01_4_01_4.html',1,'std']]],
  ['hash_3c_20cl_3a_3asycl_3a_3akernel_20_3e',['hash&lt; cl::sycl::kernel &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1kernel_01_4.html',1,'std']]],
  ['hash_3c_20cl_3a_3asycl_3a_3aplatform_20_3e',['hash&lt; cl::sycl::platform &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1platform_01_4.html',1,'std']]],
  ['hash_3c_20cl_3a_3asycl_3a_3aprogram_20_3e',['hash&lt; cl::sycl::program &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1program_01_4.html',1,'std']]],
  ['hash_3c_20cl_3a_3asycl_3a_3aqueue_20_3e',['hash&lt; cl::sycl::queue &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1queue_01_4.html',1,'std']]],
  ['hash_3c_20cl_3a_3asycl_3a_3asampler_20_3e',['hash&lt; cl::sycl::sampler &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1sampler_01_4.html',1,'std']]],
  ['hash_3c_20cl_3a_3asycl_3a_3astream_20_3e',['hash&lt; cl::sycl::stream &gt;',['../structstd_1_1hash_3_01cl_1_1sycl_1_1stream_01_4.html',1,'std']]],
  ['host_5faccess',['host_access',['../classcl_1_1sycl_1_1codeplay_1_1property_1_1buffer_1_1host__access.html',1,'cl::sycl::codeplay::property::buffer']]],
  ['host_5fhandler',['host_handler',['../classcl_1_1sycl_1_1codeplay_1_1host__handler.html',1,'cl::sycl::codeplay']]],
  ['host_5fselector',['host_selector',['../classcl_1_1sycl_1_1host__selector.html',1,'cl::sycl']]]
];
