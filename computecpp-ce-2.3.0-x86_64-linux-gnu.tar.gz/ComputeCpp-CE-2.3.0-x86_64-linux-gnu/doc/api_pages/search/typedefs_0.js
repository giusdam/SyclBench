var searchData=
[
  ['allocator_5ftype',['allocator_type',['../classcl_1_1sycl_1_1buffer.html#afe21091ab10487cc72d5294c934aa367',1,'cl::sycl::buffer::allocator_type()'],['../classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a831a1547ed62537c5686945aa29fd7de',1,'cl::sycl::buffer&lt; const T, dimensions, AllocatorT &gt;::allocator_type()']]],
  ['async_5fhandler',['async_handler',['../namespacecl_1_1sycl.html#ad5040b06655698bb2fe2f6714ef975e7',1,'cl::sycl']]],
  ['atomic_5ffloat',['atomic_float',['../namespacecl_1_1sycl.html#ab1864563485ff5f1a19f2e6cfc3bb206',1,'cl::sycl']]],
  ['atomic_5fint',['atomic_int',['../namespacecl_1_1sycl.html#a05538716a9a1f3d4ceab84b3eeba18d5',1,'cl::sycl']]],
  ['atomic_5fuint',['atomic_uint',['../namespacecl_1_1sycl.html#a93a6cbe1269bacbd085d24a611aac4b5',1,'cl::sycl']]]
];
