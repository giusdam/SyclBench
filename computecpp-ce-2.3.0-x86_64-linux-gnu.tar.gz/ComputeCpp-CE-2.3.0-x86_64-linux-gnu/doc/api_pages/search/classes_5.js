var searchData=
[
  ['feature_5fnot_5fsupported',['feature_not_supported',['../classcl_1_1sycl_1_1feature__not__supported.html',1,'cl::sycl']]]
];
