var searchData=
[
  ['global_5fmem_5fcache_5ftype',['global_mem_cache_type',['../namespacecl_1_1sycl_1_1info.html#a8986fcccc4479065bdbf37d9b9d8def5',1,'cl::sycl::info']]]
];
