var searchData=
[
  ['make_5fexception_5flist',['make_exception_list',['../classcl_1_1sycl_1_1exception__list.html#a5cd7c0f0581a565441e616e69df225a4',1,'cl::sycl::exception_list']]]
];
