var searchData=
[
  ['w',['w',['../structcl_1_1sycl_1_1elem.html#a391e19e48ff05630f1f1fdd0b49e08b3',1,'cl::sycl::elem']]],
  ['wait',['wait',['../classcl_1_1sycl_1_1device__event.html#a25500aca0cb370b7648728462d370f4f',1,'cl::sycl::device_event::wait()'],['../classcl_1_1sycl_1_1event.html#a4ce1019bb7e0c38e58339d17548e81f7',1,'cl::sycl::event::wait()'],['../classcl_1_1sycl_1_1event.html#ab97bac115293bfbf373d21712e772f25',1,'cl::sycl::event::wait(const vector_class&lt; event &gt; &amp;eventList)'],['../classcl_1_1sycl_1_1queue.html#ac46bc8ee7cff0a3f77c7afb7d60184b4',1,'cl::sycl::queue::wait()']]],
  ['wait_5fand_5fthrow',['wait_and_throw',['../classcl_1_1sycl_1_1event.html#af651e36e8780b75a851c7587cc9c05a7',1,'cl::sycl::event::wait_and_throw()'],['../classcl_1_1sycl_1_1event.html#a1b85a4a419b3176c9b269d9c00029694',1,'cl::sycl::event::wait_and_throw(const vector_class&lt; event &gt; &amp;eventList)'],['../classcl_1_1sycl_1_1queue.html#abfa510446db9f4edd0c16270b199a232',1,'cl::sycl::queue::wait_and_throw()']]],
  ['wait_5ffor',['wait_for',['../classcl_1_1sycl_1_1group.html#afb7f92025ff0f53ea43010425f2ef9d1',1,'cl::sycl::group::wait_for()'],['../classcl_1_1sycl_1_1nd__item.html#a3135d8455ae084702d4627f3cfe76b4a',1,'cl::sycl::nd_item::wait_for()']]],
  ['weak_5fptr_5fclass',['weak_ptr_class',['../namespacecl_1_1sycl.html#a8cc65d5e679773a053245819fa2a13de',1,'cl::sycl']]],
  ['what',['what',['../classcl_1_1sycl_1_1exception.html#a33eb33409014adfca8a71555ec20a5c8',1,'cl::sycl::exception']]],
  ['work_5fgroup_5fsize',['work_group_size',['../namespacecl_1_1sycl_1_1info.html#a592a8baeff484e312c7f5ce6192a6ccfafffb71c6a8897dd2d01f9c13ef174cb4',1,'cl::sycl::info']]],
  ['write',['write',['../namespacecl_1_1sycl_1_1codeplay.html#aa647be847f5f30d9ea39f4a6a2e8cb6eaefb2a684e4afb7d55e6147fbe5a332ee',1,'cl::sycl::codeplay::write()'],['../namespacecl_1_1sycl_1_1access.html#ade7472cc9b6db9b3cd47fb9f3bc8c450aefb2a684e4afb7d55e6147fbe5a332ee',1,'cl::sycl::access::write()']]],
  ['write_5fback',['write_back',['../namespacecl_1_1sycl.html#a8e7597dd8765b96549545e95337b412f',1,'cl::sycl']]]
];
