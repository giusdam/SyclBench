var searchData=
[
  ['kernel',['kernel',['../classcl_1_1sycl_1_1kernel.html#ab01773a47034912fed1a10982eb45f24',1,'cl::sycl::kernel::kernel(const kernel &amp;rhs)=default'],['../classcl_1_1sycl_1_1kernel.html#ab456729fd35d35825a89f6e5fd46b460',1,'cl::sycl::kernel::kernel(kernel &amp;&amp;rhs)=default'],['../classcl_1_1sycl_1_1kernel.html#ad9c2efd107a71f403f6c4afe7c2cfa00',1,'cl::sycl::kernel::kernel(cl_kernel clKernel, const context &amp;syclContext)']]]
];
