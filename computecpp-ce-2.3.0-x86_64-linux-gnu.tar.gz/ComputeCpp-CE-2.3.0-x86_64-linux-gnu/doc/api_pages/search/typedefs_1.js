var searchData=
[
  ['base_5ft',['base_t',['../classcl_1_1sycl_1_1nd__item.html#ad6741fcac4836578651eea62f667f101',1,'cl::sycl::nd_item::base_t()'],['../namespacecl_1_1sycl.html#a9eee22f693b60aaec7c20d77be08aba7',1,'cl::sycl::base_t()']]],
  ['bit_5fand',['bit_and',['../namespacecl_1_1sycl_1_1experimental.html#ae00042d4ead606ce45bd33d054a8f81a',1,'cl::sycl::experimental']]],
  ['bit_5for',['bit_or',['../namespacecl_1_1sycl_1_1experimental.html#aa8f0837f0554f7651ba6194a354a3004',1,'cl::sycl::experimental']]],
  ['bit_5fxor',['bit_xor',['../namespacecl_1_1sycl_1_1experimental.html#a4787ba2841557eba12717c3dd1aac035',1,'cl::sycl::experimental']]],
  ['bitset_5fclass',['bitset_class',['../namespacecl_1_1sycl.html#a137610666a25428027b505d0b4d98fd0',1,'cl::sycl']]],
  ['byte',['byte',['../namespacecl_1_1sycl.html#a8a434f950a184b3d0d3e123250c5e66a',1,'cl::sycl']]]
];
