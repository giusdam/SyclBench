var searchData=
[
  ['value_5ftype',['value_type',['../classcl_1_1sycl_1_1buffer.html#a6a4c51dffc61ab0e4f201e67d91c9353',1,'cl::sycl::buffer::value_type()'],['../classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#aa529fdd56b9e651dc9137712c049d928',1,'cl::sycl::buffer&lt; const T, dimensions, AllocatorT &gt;::value_type()'],['../classcl_1_1sycl_1_1exception__list.html#a7b6cf9a1dee69091a7a071129991bccb',1,'cl::sycl::exception_list::value_type()'],['../classcl_1_1sycl_1_1experimental_1_1usm__allocator.html#a3ead9742d45549218954a93101410472',1,'cl::sycl::experimental::usm_allocator::value_type()'],['../classcl_1_1sycl_1_1multi__ptr.html#a8445035b4f78ba3ac477fc1db447f0eb',1,'cl::sycl::multi_ptr::value_type()'],['../classcl_1_1sycl_1_1multi__ptr_3_01void_00_01asp_01_4.html#aee627a1adcc51b7ed1367752b5a04708',1,'cl::sycl::multi_ptr&lt; void, asp &gt;::value_type()'],['../classcl_1_1sycl_1_1multi__ptr_3_01const_01void_00_01asp_01_4.html#a649c1d5cb621fed20791f8f8669a2605',1,'cl::sycl::multi_ptr&lt; const void, asp &gt;::value_type()']]],
  ['vec',['vec',['../classcl_1_1sycl_1_1vec.html',1,'cl::sycl']]],
  ['vec_2eh',['vec.h',['../vec_8h.html',1,'']]],
  ['vec_5fcommon_2eh',['vec_common.h',['../vec__common_8h.html',1,'']]],
  ['vec_5fload_5fstore_2eh',['vec_load_store.h',['../vec__load__store_8h.html',1,'']]],
  ['vec_5fmacros_2eh',['vec_macros.h',['../vec__macros_8h.html',1,'']]],
  ['vec_5ftypes_5fdefines_2eh',['vec_types_defines.h',['../vec__types__defines_8h.html',1,'']]],
  ['vector_5fclass',['vector_class',['../namespacecl_1_1sycl.html#a0a3b58674c77d248758b6bee05800ac5',1,'cl::sycl']]],
  ['vendor',['vendor',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a7c3613dba5171cb6027c67835dd3b9d4',1,'cl::sycl::info::vendor()'],['../namespacecl_1_1sycl_1_1info.html#a3ea7e38ccbc7de5270c4f69bbae20463a7c3613dba5171cb6027c67835dd3b9d4',1,'cl::sycl::info::vendor()']]],
  ['vendor_5fid',['vendor_id',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a96b1f972094b863cafcacb8fc48b9bea',1,'cl::sycl::info']]],
  ['version',['version',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a2af72f100c356273d46284f6fd1dfc08',1,'cl::sycl::info::version()'],['../namespacecl_1_1sycl_1_1info.html#a3ea7e38ccbc7de5270c4f69bbae20463a2af72f100c356273d46284f6fd1dfc08',1,'cl::sycl::info::version()']]],
  ['version_2eh',['version.h',['../version_8h.html',1,'']]]
];
