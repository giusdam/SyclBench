var searchData=
[
  ['ldexp',['ldexp',['../namespacecl_1_1sycl.html#ab4407e566cabe63cb2eb7cf668f252e3',1,'cl::sycl::ldexp(F x, Integral k) noexcept'],['../namespacecl_1_1sycl.html#a3720d71cf650c1a5b7ed888430e01b5e',1,'cl::sycl::ldexp(F x, const int k) noexcept']]],
  ['length',['length',['../namespacecl_1_1sycl.html#a1dfa93840edf642aa269e191ea4a4648',1,'cl::sycl']]],
  ['lgamma',['lgamma',['../namespacecl_1_1sycl.html#ae1ea28bcc06c0c715f89dca92acbc6ff',1,'cl::sycl']]],
  ['lgamma_5fr',['lgamma_r',['../namespacecl_1_1sycl.html#a3207c1198c47f17871c2f78cd37769d1',1,'cl::sycl']]],
  ['link',['link',['../classcl_1_1sycl_1_1program.html#a3ba4863592f4e5a1b93eb97e1dbf03b5',1,'cl::sycl::program::link(string_class linkOptions=&quot;&quot;)'],['../classcl_1_1sycl_1_1program.html#ae0e598d9e39214d685b0e47ab0b68597',1,'cl::sycl::program::link(const char *linkOptions)']]],
  ['load',['load',['../structcl_1_1sycl_1_1atomic.html#a012c1b20e85641a21b9a4bdcacde0441',1,'cl::sycl::atomic']]],
  ['log',['log',['../namespacecl_1_1sycl.html#a1fd3eb43ccd7f5aa46d0e53c20f3ea1e',1,'cl::sycl::log()'],['../namespacecl_1_1sycl_1_1half__precision.html#a2b30877c247a6211c51f1f97dc7e6c4e',1,'cl::sycl::half_precision::log()'],['../namespacecl_1_1sycl_1_1native.html#a9d3f716a280db4d32c85a85b6091f051',1,'cl::sycl::native::log()']]],
  ['log10',['log10',['../namespacecl_1_1sycl.html#a85b384cb275cbecc76f84eec0bbc8521',1,'cl::sycl::log10()'],['../namespacecl_1_1sycl_1_1half__precision.html#ab70ccfb6e7a1b098d2e8d61100f01073',1,'cl::sycl::half_precision::log10()'],['../namespacecl_1_1sycl_1_1native.html#a1b8c09eab9a8af9332b03e8a38bb270d',1,'cl::sycl::native::log10()']]],
  ['log1p',['log1p',['../namespacecl_1_1sycl.html#a075f242d776bf3f9bb04a441e4389696',1,'cl::sycl']]],
  ['log2',['log2',['../namespacecl_1_1sycl.html#a68a6eca4686f47f3fbd5aa17df2b241b',1,'cl::sycl::log2()'],['../namespacecl_1_1sycl_1_1half__precision.html#a68fb3c8db42cea0fe06fe9428d032c2f',1,'cl::sycl::half_precision::log2()'],['../namespacecl_1_1sycl_1_1native.html#a7ad9aa0a1198f9772f8d0cf417d2edcd',1,'cl::sycl::native::log2()']]],
  ['logb',['logb',['../namespacecl_1_1sycl.html#a2b69c5e7c0b61efc1aec10399f665823',1,'cl::sycl']]]
];
