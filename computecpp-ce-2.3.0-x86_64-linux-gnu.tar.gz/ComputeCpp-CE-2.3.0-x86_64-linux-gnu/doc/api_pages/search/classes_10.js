var searchData=
[
  ['range',['range',['../classcl_1_1sycl_1_1range.html',1,'cl::sycl']]],
  ['range_3c_201_20_3e',['range&lt; 1 &gt;',['../classcl_1_1sycl_1_1range_3_011_01_4.html',1,'cl::sycl']]],
  ['range_3c_202_20_3e',['range&lt; 2 &gt;',['../classcl_1_1sycl_1_1range_3_012_01_4.html',1,'cl::sycl']]],
  ['range_3c_203_20_3e',['range&lt; 3 &gt;',['../classcl_1_1sycl_1_1range_3_013_01_4.html',1,'cl::sycl']]],
  ['rebind',['rebind',['../structcl_1_1sycl_1_1experimental_1_1usm__allocator_1_1rebind.html',1,'cl::sycl::experimental::usm_allocator']]],
  ['runtime_5ferror',['runtime_error',['../classcl_1_1sycl_1_1runtime__error.html',1,'cl::sycl']]]
];
