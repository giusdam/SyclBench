var searchData=
[
  ['vendor',['vendor',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a7c3613dba5171cb6027c67835dd3b9d4',1,'cl::sycl::info::vendor()'],['../namespacecl_1_1sycl_1_1info.html#a3ea7e38ccbc7de5270c4f69bbae20463a7c3613dba5171cb6027c67835dd3b9d4',1,'cl::sycl::info::vendor()']]],
  ['vendor_5fid',['vendor_id',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a96b1f972094b863cafcacb8fc48b9bea',1,'cl::sycl::info']]],
  ['version',['version',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a2af72f100c356273d46284f6fd1dfc08',1,'cl::sycl::info::version()'],['../namespacecl_1_1sycl_1_1info.html#a3ea7e38ccbc7de5270c4f69bbae20463a2af72f100c356273d46284f6fd1dfc08',1,'cl::sycl::info::version()']]]
];
