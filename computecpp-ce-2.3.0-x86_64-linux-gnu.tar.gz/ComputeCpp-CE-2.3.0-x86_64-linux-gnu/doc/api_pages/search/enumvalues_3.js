var searchData=
[
  ['dec',['dec',['../namespacecl_1_1sycl.html#aae8e7aa729b49299771cd464d4b17370a1feea25ecb958229287f885aebe7c49b',1,'cl::sycl']]],
  ['defaultfloat',['defaultfloat',['../namespacecl_1_1sycl.html#aae8e7aa729b49299771cd464d4b17370a2ef4603357809b52b88d59db2f18c4da',1,'cl::sycl']]],
  ['denorm',['denorm',['../namespacecl_1_1sycl_1_1info.html#a1f763ed06ac5c82a02a7425bd7739745ad14934558f81f7ea5012ab4de4031017',1,'cl::sycl::info']]],
  ['device',['device',['../namespacecl_1_1sycl_1_1experimental_1_1usm.html#a6c249557f3c2cb3ff34bce095c8d4125a913f9c49dcb544e2087cee284f4a00b7',1,'cl::sycl::experimental::usm']]],
  ['device_5ftype',['device_type',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5ac09593f6075100eef79c8f4da08afa16',1,'cl::sycl::info']]],
  ['devices',['devices',['../namespacecl_1_1sycl_1_1info.html#a1a5898274a448ac592ebbcee928939c1ae0212e54ec3a2a120ca0d321b3a60c78',1,'cl::sycl::info::devices()'],['../namespacecl_1_1sycl_1_1info.html#a6645cc5581516494ff2409d887258574ae0212e54ec3a2a120ca0d321b3a60c78',1,'cl::sycl::info::devices()']]],
  ['disable_5fwrite_5fback',['disable_write_back',['../namespacecl_1_1sycl.html#a8e7597dd8765b96549545e95337b412fa040b5b5d9c7dcfb0bfc7b016b1b5cb95',1,'cl::sycl']]],
  ['discard_5fread_5fwrite',['discard_read_write',['../namespacecl_1_1sycl_1_1access.html#ade7472cc9b6db9b3cd47fb9f3bc8c450a5521dbab91d3894807c5ad7e84e14f4b',1,'cl::sycl::access']]],
  ['discard_5fwrite',['discard_write',['../namespacecl_1_1sycl_1_1access.html#ade7472cc9b6db9b3cd47fb9f3bc8c450af0d9952b32031a9b0c9606400dff53f9',1,'cl::sycl::access']]],
  ['double_5ffp_5fconfig',['double_fp_config',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a758a728dea63697dd78fdda02d46cdd4',1,'cl::sycl::info']]],
  ['driver_5fversion',['driver_version',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5ad5612938744d9340b9b447854c8a18fb',1,'cl::sycl::info']]]
];
