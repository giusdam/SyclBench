var searchData=
[
  ['true_5ft',['true_t',['../namespacecl_1_1sycl_1_1access.html#af1c616691dbceeaca9cdd537a8ab0af9a1b756892a15e10bdbdfe033bf55e8d03',1,'cl::sycl::access']]]
];
