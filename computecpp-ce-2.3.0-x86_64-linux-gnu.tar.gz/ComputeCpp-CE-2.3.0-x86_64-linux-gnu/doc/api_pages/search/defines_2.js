var searchData=
[
  ['sycl_5fbackend_5fhost',['SYCL_BACKEND_HOST',['../backend_8h.html#a83b62b480ac00a8485c9a8e9f6c71117',1,'backend.h']]],
  ['sycl_5fbackend_5fopencl',['SYCL_BACKEND_OPENCL',['../backend_8h.html#a104744327bb4e2438eb704d4e01ff5f6',1,'backend.h']]],
  ['sycl_5flanguage_5fversion',['SYCL_LANGUAGE_VERSION',['../predefines_8h.html#a9416773c40b09aa5eee1d98b1954aee4',1,'predefines.h']]]
];
