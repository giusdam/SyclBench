var searchData=
[
  ['interopflag',['interopFlag',['../classcl_1_1sycl_1_1context.html#a4e420b2f86d6be8b12cb3fa49e587a47',1,'cl::sycl::context']]]
];
