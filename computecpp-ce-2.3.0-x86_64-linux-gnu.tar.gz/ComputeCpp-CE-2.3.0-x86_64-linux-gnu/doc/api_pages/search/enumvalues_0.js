var searchData=
[
  ['a',['a',['../namespacecl_1_1sycl.html#a8557ea72c6739001cf30a301567cf3dfa0cc175b9c0f1b6a831c399e269772661',1,'cl::sycl']]],
  ['accelerator',['accelerator',['../namespacecl_1_1sycl.html#aa64f3cdf8b4712806126ec95efa7d1b6a226522b5dff606dbd2bc2538e0d26f6c',1,'cl::sycl::accelerator()'],['../namespacecl_1_1sycl_1_1info.html#a839771ab6b37e25ae67d5c8a2d4d97f8a226522b5dff606dbd2bc2538e0d26f6c',1,'cl::sycl::info::accelerator()']]],
  ['address_5fbits',['address_bits',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5aa7c2ecb69c55eb87bc76205d634a9c9f',1,'cl::sycl::info']]],
  ['all',['all',['../namespacecl_1_1sycl_1_1info.html#a839771ab6b37e25ae67d5c8a2d4d97f8aa181a603769c1f98ad927e7367c7aa51',1,'cl::sycl::info']]],
  ['argb',['argb',['../namespacecl_1_1sycl.html#a8557ea72c6739001cf30a301567cf3dfa160d69bb77496bdc5035cf5b53fd273f',1,'cl::sycl']]],
  ['atomic',['atomic',['../namespacecl_1_1sycl_1_1access.html#ade7472cc9b6db9b3cd47fb9f3bc8c450a23d33884d600e542d097cd3933df2ae4',1,'cl::sycl::access']]],
  ['attributes',['attributes',['../namespacecl_1_1sycl_1_1info.html#a9845a480a36d09200c5355a775fc1fa1a736b91750e516139acc13c5eb6564f92',1,'cl::sycl::info']]],
  ['automatic',['automatic',['../namespacecl_1_1sycl_1_1info.html#a839771ab6b37e25ae67d5c8a2d4d97f8a2bd9c0ed00116be1258e0cc66617d7c8',1,'cl::sycl::info::automatic()'],['../namespacecl_1_1sycl.html#a16ab217f4d07c904f763adf0a270d1c0a2bd9c0ed00116be1258e0cc66617d7c8',1,'cl::sycl::automatic()']]]
];
