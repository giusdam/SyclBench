var searchData=
[
  ['m_5ffallbackqueue',['m_fallbackQueue',['../classcl_1_1sycl_1_1handler.html#aca8ae9b682242271c828237b136d2646',1,'cl::sycl::handler']]],
  ['m_5fidx',['m_idx',['../classindex__array__base.html#a4f1802f917b0fb369991930b635e956f',1,'index_array_base::m_idx()'],['../index__array_8h.html#a53f634ddbffc7a9d1f6dc3df17de0fe5',1,'m_idx():&#160;index_array.h']]],
  ['m_5fimpl',['m_impl',['../classcl_1_1sycl_1_1context.html#ae983b0c1c17fbc2e4bcea545108b60a1',1,'cl::sycl::context::m_impl()'],['../classcl_1_1sycl_1_1device__selector.html#ac83830e11e1b46f36d70e651e9fc498c',1,'cl::sycl::device_selector::m_impl()'],['../classcl_1_1sycl_1_1platform.html#a8ddd9c0644c6d106a2e50697305bfcf8',1,'cl::sycl::platform::m_impl()']]],
  ['m_5flocalid',['m_localId',['../structcl_1_1sycl_1_1experimental_1_1sub__group.html#a75b033340951c253f5cac89ec3158b51',1,'cl::sycl::experimental::sub_group']]],
  ['m_5flocalrange',['m_localRange',['../structcl_1_1sycl_1_1experimental_1_1sub__group.html#af9d349ee0bc5ee05bee7b2641d0ea22a',1,'cl::sycl::experimental::sub_group']]],
  ['m_5fmaxlocalrange',['m_maxLocalRange',['../structcl_1_1sycl_1_1experimental_1_1sub__group.html#a5eeaab3029163ec641aed03f0aa480f5',1,'cl::sycl::experimental::sub_group']]],
  ['m_5fnumkernels',['m_numKernels',['../classcl_1_1sycl_1_1handler.html#ac7bffc7ce382906014d6cfaafb7c75e9',1,'cl::sycl::handler']]],
  ['m_5fparamvec',['m_paramVec',['../classcl_1_1sycl_1_1handler.html#a3d6d146a3f005c5a27e653a5dab16550',1,'cl::sycl::handler']]],
  ['m_5fqueue',['m_queue',['../classcl_1_1sycl_1_1handler.html#a53746faca0e6189185ff0218bbda5f22',1,'cl::sycl::handler']]],
  ['m_5fsubgroupid',['m_subGroupId',['../structcl_1_1sycl_1_1experimental_1_1sub__group.html#aafd828c40fcb56d1dbdf3fe51ed40f6a',1,'cl::sycl::experimental::sub_group']]],
  ['m_5fsubgrouprange',['m_subGroupRange',['../structcl_1_1sycl_1_1experimental_1_1sub__group.html#acb05cc109f11822f24ae60be7a8b0a7a',1,'cl::sycl::experimental::sub_group']]],
  ['m_5ftrans',['m_trans',['../classcl_1_1sycl_1_1handler.html#a65cd7a5b02ea526bb946eff87188afa1',1,'cl::sycl::handler']]],
  ['m_5funiformsubgrouprange',['m_uniformSubGroupRange',['../structcl_1_1sycl_1_1experimental_1_1sub__group.html#a86e987064ed4db71f6206433f19deb64',1,'cl::sycl::experimental::sub_group']]]
];
