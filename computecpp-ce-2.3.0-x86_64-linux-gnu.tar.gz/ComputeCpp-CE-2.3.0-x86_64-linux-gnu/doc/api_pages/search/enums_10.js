var searchData=
[
  ['write_5fback',['write_back',['../namespacecl_1_1sycl.html#a8e7597dd8765b96549545e95337b412f',1,'cl::sycl']]]
];
