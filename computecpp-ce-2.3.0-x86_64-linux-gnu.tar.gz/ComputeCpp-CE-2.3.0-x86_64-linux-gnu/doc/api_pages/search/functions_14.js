var searchData=
[
  ['wait',['wait',['../classcl_1_1sycl_1_1device__event.html#a25500aca0cb370b7648728462d370f4f',1,'cl::sycl::device_event::wait()'],['../classcl_1_1sycl_1_1event.html#a4ce1019bb7e0c38e58339d17548e81f7',1,'cl::sycl::event::wait()'],['../classcl_1_1sycl_1_1event.html#ab97bac115293bfbf373d21712e772f25',1,'cl::sycl::event::wait(const vector_class&lt; event &gt; &amp;eventList)'],['../classcl_1_1sycl_1_1queue.html#ac46bc8ee7cff0a3f77c7afb7d60184b4',1,'cl::sycl::queue::wait()']]],
  ['wait_5fand_5fthrow',['wait_and_throw',['../classcl_1_1sycl_1_1event.html#af651e36e8780b75a851c7587cc9c05a7',1,'cl::sycl::event::wait_and_throw()'],['../classcl_1_1sycl_1_1event.html#a1b85a4a419b3176c9b269d9c00029694',1,'cl::sycl::event::wait_and_throw(const vector_class&lt; event &gt; &amp;eventList)'],['../classcl_1_1sycl_1_1queue.html#abfa510446db9f4edd0c16270b199a232',1,'cl::sycl::queue::wait_and_throw()']]],
  ['wait_5ffor',['wait_for',['../classcl_1_1sycl_1_1group.html#afb7f92025ff0f53ea43010425f2ef9d1',1,'cl::sycl::group::wait_for()'],['../classcl_1_1sycl_1_1nd__item.html#a3135d8455ae084702d4627f3cfe76b4a',1,'cl::sycl::nd_item::wait_for()']]],
  ['what',['what',['../classcl_1_1sycl_1_1exception.html#a33eb33409014adfca8a71555ec20a5c8',1,'cl::sycl::exception']]]
];
