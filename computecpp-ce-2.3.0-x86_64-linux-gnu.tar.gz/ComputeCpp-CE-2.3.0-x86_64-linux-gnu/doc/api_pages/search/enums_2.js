var searchData=
[
  ['context',['context',['../namespacecl_1_1sycl_1_1info.html#a1a5898274a448ac592ebbcee928939c1',1,'cl::sycl::info']]],
  ['coordinate_5fnormalization_5fmode',['coordinate_normalization_mode',['../namespacecl_1_1sycl.html#a7affaf1f828474ac7e461ae6e9831367',1,'cl::sycl']]]
];
