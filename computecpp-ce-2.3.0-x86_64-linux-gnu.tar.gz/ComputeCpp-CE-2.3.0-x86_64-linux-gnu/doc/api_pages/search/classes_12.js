var searchData=
[
  ['use_5fhost_5fptr',['use_host_ptr',['../classcl_1_1sycl_1_1property_1_1buffer_1_1use__host__ptr.html',1,'cl::sycl::property::buffer']]],
  ['use_5fmutex',['use_mutex',['../classcl_1_1sycl_1_1property_1_1buffer_1_1use__mutex.html',1,'cl::sycl::property::buffer']]],
  ['use_5fonchip_5fmemory',['use_onchip_memory',['../classcl_1_1sycl_1_1codeplay_1_1property_1_1buffer_1_1use__onchip__memory.html',1,'cl::sycl::codeplay::property::buffer']]],
  ['usm_5fallocator',['usm_allocator',['../classcl_1_1sycl_1_1experimental_1_1usm__allocator.html',1,'cl::sycl::experimental']]]
];
