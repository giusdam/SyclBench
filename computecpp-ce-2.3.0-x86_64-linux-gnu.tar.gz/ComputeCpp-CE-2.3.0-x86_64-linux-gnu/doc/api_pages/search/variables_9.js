var searchData=
[
  ['kdims',['kDims',['../classcl_1_1sycl_1_1accessor_3_01elem_t_00_01k_dims_00_01k_mode_00_01access_1_1target_1_1host__buf15cbef5585a67b9df703426df07becd.html#aeda151125d5382885047e24a7df21166',1,'cl::sycl::accessor&lt; elemT, kDims, kMode, access::target::host_buffer, access::placeholder::false_t &gt;::kDims()'],['../namespacecl_1_1sycl.html#a3f8af2d88cd5cbd85ba1496c3da01a48',1,'cl::sycl::kDims()']]],
  ['kmode',['kMode',['../namespacecl_1_1sycl.html#a8e0ac3ee309ca11111cfe5f073ada8c1',1,'cl::sycl']]],
  ['ktarget',['kTarget',['../namespacecl_1_1sycl.html#a0b53769ff68f9a0afeb5c5f2342dcff4',1,'cl::sycl']]]
];
