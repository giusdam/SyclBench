var searchData=
[
  ['nan',['nan',['../namespacecl_1_1sycl.html#aad55322c211156d6863387f695eb8b38',1,'cl::sycl::nan(Integral nancode) noexcept-&gt; detail::matching_float_t&lt; Integral &gt;'],['../namespacecl_1_1sycl.html#a052a425f14308d76fe62938f4f7ec7a1',1,'cl::sycl::nan(Integral nancode) noexcept']]],
  ['nd_5fitem',['nd_item',['../classcl_1_1sycl_1_1nd__item.html#a0ed8731d6921cff76a2797b2a9672435',1,'cl::sycl::nd_item::nd_item()=delete'],['../classcl_1_1sycl_1_1nd__item.html#a3fd1d1d82237ece4c47db8314e6a27b4',1,'cl::sycl::nd_item::nd_item(const nd_item &amp;rhs)=default'],['../classcl_1_1sycl_1_1nd__item.html#a5cc0b79d92c5e1393f790977d00d449e',1,'cl::sycl::nd_item::nd_item(const nd_item&lt; dimensions2 &gt; &amp;rhs)'],['../classcl_1_1sycl_1_1nd__item.html#a401d82b976c4f39357b0f20de04ead62',1,'cl::sycl::nd_item::nd_item(const detail::nd_item_base &amp;i)']]],
  ['nd_5frange',['nd_range',['../classcl_1_1sycl_1_1nd__range.html#a79ee30bf7879518ed4de381256c29fa3',1,'cl::sycl::nd_range::nd_range(const range&lt; dimensions &gt; globalRange, const range&lt; dimensions &gt; localRange, const id&lt; dimensions &gt; globalOffset=id&lt; dimensions &gt;())'],['../classcl_1_1sycl_1_1nd__range.html#a92b969ce9f165c180b796c7423da02d1',1,'cl::sycl::nd_range::nd_range(const detail::nd_range_base &amp;ndRangeBase)']]],
  ['nextafter',['nextafter',['../namespacecl_1_1sycl.html#abb8def12098632a1637fafe185e16d47',1,'cl::sycl']]],
  ['normalize',['normalize',['../namespacecl_1_1sycl.html#a2b407874e157b68a6eb252a88a1c5796',1,'cl::sycl']]]
];
