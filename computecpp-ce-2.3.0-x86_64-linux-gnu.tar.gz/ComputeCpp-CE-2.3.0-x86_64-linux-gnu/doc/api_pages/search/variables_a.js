var searchData=
[
  ['localrange',['localRange',['../namespacecl_1_1sycl.html#a17e2c535e99ddcd61202a5366c835281',1,'cl::sycl']]]
];
