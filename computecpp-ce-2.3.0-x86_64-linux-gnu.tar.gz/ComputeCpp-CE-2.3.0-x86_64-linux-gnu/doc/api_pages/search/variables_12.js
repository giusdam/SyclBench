var searchData=
[
  ['y',['y',['../structcl_1_1sycl_1_1elem.html#a5cfcdcdca9ada16b8ec61188feeeb428',1,'cl::sycl::elem']]]
];
