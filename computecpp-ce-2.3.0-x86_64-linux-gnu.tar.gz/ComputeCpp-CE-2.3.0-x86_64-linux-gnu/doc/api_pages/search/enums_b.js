var searchData=
[
  ['memory_5forder',['memory_order',['../namespacecl_1_1sycl.html#a2145358fe52a1f70ad8cb1ca7ce89a76',1,'cl::sycl']]],
  ['memory_5ftype',['memory_type',['../namespacecl_1_1sycl_1_1codeplay.html#aa9503fa6c8096a10957afbcc6d36c953',1,'cl::sycl::codeplay']]],
  ['mode',['mode',['../namespacecl_1_1sycl_1_1access.html#ade7472cc9b6db9b3cd47fb9f3bc8c450',1,'cl::sycl::access']]]
];
