var searchData=
[
  ['host_5faccess_5fmode',['host_access_mode',['../namespacecl_1_1sycl_1_1codeplay.html#aa647be847f5f30d9ea39f4a6a2e8cb6e',1,'cl::sycl::codeplay']]]
];
