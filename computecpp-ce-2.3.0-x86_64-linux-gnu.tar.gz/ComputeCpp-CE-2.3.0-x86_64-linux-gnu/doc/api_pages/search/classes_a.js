var searchData=
[
  ['link_5fprogram_5ferror',['link_program_error',['../classcl_1_1sycl_1_1link__program__error.html',1,'cl::sycl']]]
];
