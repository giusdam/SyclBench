var searchData=
[
  ['stream_5fmanipulator',['stream_manipulator',['../namespacecl_1_1sycl.html#aae8e7aa729b49299771cd464d4b17370',1,'cl::sycl']]]
];
