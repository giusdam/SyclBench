var searchData=
[
  ['kdims',['kDims',['../classcl_1_1sycl_1_1accessor_3_01elem_t_00_01k_dims_00_01k_mode_00_01access_1_1target_1_1host__buf15cbef5585a67b9df703426df07becd.html#aeda151125d5382885047e24a7df21166',1,'cl::sycl::accessor&lt; elemT, kDims, kMode, access::target::host_buffer, access::placeholder::false_t &gt;::kDims()'],['../namespacecl_1_1sycl.html#a3f8af2d88cd5cbd85ba1496c3da01a48',1,'cl::sycl::kDims()']]],
  ['kernel',['kernel',['../classcl_1_1sycl_1_1kernel.html',1,'cl::sycl']]],
  ['kernel',['kernel',['../classcl_1_1sycl_1_1kernel.html#ab01773a47034912fed1a10982eb45f24',1,'cl::sycl::kernel::kernel(const kernel &amp;rhs)=default'],['../classcl_1_1sycl_1_1kernel.html#ab456729fd35d35825a89f6e5fd46b460',1,'cl::sycl::kernel::kernel(kernel &amp;&amp;rhs)=default'],['../classcl_1_1sycl_1_1kernel.html#ad9c2efd107a71f403f6c4afe7c2cfa00',1,'cl::sycl::kernel::kernel(cl_kernel clKernel, const context &amp;syclContext)'],['../namespacecl_1_1sycl_1_1info.html#a9845a480a36d09200c5355a775fc1fa1',1,'cl::sycl::info::kernel()']]],
  ['kernel_2eh',['kernel.h',['../kernel_8h.html',1,'']]],
  ['kernel_5ferror',['kernel_error',['../classcl_1_1sycl_1_1kernel__error.html',1,'cl::sycl']]],
  ['kernel_5fsub_5fgroup',['kernel_sub_group',['../namespacecl_1_1sycl_1_1info.html#aaee38a765a8d99422ac3d2bbd4a79b8e',1,'cl::sycl::info']]],
  ['kernel_5fwork_5fgroup',['kernel_work_group',['../namespacecl_1_1sycl_1_1info.html#a592a8baeff484e312c7f5ce6192a6ccf',1,'cl::sycl::info']]],
  ['kmode',['kMode',['../namespacecl_1_1sycl.html#a8e0ac3ee309ca11111cfe5f073ada8c1',1,'cl::sycl']]],
  ['ktarget',['kTarget',['../namespacecl_1_1sycl.html#a0b53769ff68f9a0afeb5c5f2342dcff4',1,'cl::sycl']]]
];
