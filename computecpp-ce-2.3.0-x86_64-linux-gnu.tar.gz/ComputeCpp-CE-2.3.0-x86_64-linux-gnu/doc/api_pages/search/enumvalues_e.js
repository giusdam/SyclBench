var searchData=
[
  ['queue_5fprofiling',['queue_profiling',['../namespacecl_1_1sycl.html#aa64f3cdf8b4712806126ec95efa7d1b6acff13e821b304bffc11e5a8b52b78359',1,'cl::sycl::queue_profiling()'],['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5acff13e821b304bffc11e5a8b52b78359',1,'cl::sycl::info::queue_profiling()']]]
];
