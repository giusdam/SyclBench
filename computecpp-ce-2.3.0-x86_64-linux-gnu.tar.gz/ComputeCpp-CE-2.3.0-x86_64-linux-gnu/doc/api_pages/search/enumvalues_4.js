var searchData=
[
  ['enable_5fwrite_5fback',['enable_write_back',['../namespacecl_1_1sycl.html#a8e7597dd8765b96549545e95337b412fa4659ce4c4ec6673a8812a9bf3dfe56cf',1,'cl::sycl']]],
  ['endl',['endl',['../namespacecl_1_1sycl.html#aae8e7aa729b49299771cd464d4b17370a50687cdc4bc36169eb3b2948c9920715',1,'cl::sycl']]],
  ['error_5fcorrection_5fsupport',['error_correction_support',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a419c736fc210de1c55decd67e8ac9f61',1,'cl::sycl::info']]],
  ['exec_5fkernel',['exec_kernel',['../namespacecl_1_1sycl_1_1info.html#a325a35c99165b9ee10d88acd0ea73c00a8ef8a5e4446de303bfda8dee49b81b86',1,'cl::sycl::info']]],
  ['exec_5fnative_5fkernel',['exec_native_kernel',['../namespacecl_1_1sycl_1_1info.html#a325a35c99165b9ee10d88acd0ea73c00af9aac75a42a777bddf2841ef348171d7',1,'cl::sycl::info']]],
  ['execution_5fcapabilities',['execution_capabilities',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5afc1fc31ceecfb5079c46662e292a9d3e',1,'cl::sycl::info']]],
  ['extensions',['extensions',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a2ac737d240fc746cef37129b7569f08e',1,'cl::sycl::info::extensions()'],['../namespacecl_1_1sycl_1_1info.html#a3ea7e38ccbc7de5270c4f69bbae20463a2ac737d240fc746cef37129b7569f08e',1,'cl::sycl::info::extensions()']]]
];
