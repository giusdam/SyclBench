var searchData=
[
  ['gl_5fcontext_5finterop',['gl_context_interop',['../namespacecl_1_1sycl_1_1info.html#a5175660b1ec299ffb370f7e8c56a5b16',1,'cl::sycl::info']]],
  ['global_5fptr',['global_ptr',['../namespacecl_1_1sycl.html#a30e345085f7e673f139e9c8b8e98cc88',1,'cl::sycl']]]
];
