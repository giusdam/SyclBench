var searchData=
[
  ['compile_5fprogram_5ferror',['compile_program_error',['../classcl_1_1sycl_1_1compile__program__error.html',1,'cl::sycl']]],
  ['context',['context',['../classcl_1_1sycl_1_1context.html',1,'cl::sycl']]],
  ['context_5fbound',['context_bound',['../classcl_1_1sycl_1_1property_1_1buffer_1_1context__bound.html',1,'cl::sycl::property::buffer']]],
  ['cpu_5fselector',['cpu_selector',['../classcl_1_1sycl_1_1cpu__selector.html',1,'cl::sycl']]]
];
