var searchData=
[
  ['_5f_5fcomputecpp_5f_5f',['__COMPUTECPP__',['../version_8h.html#acb796ad6c5e8a6e8a47baf1cc26b234e',1,'version.h']]],
  ['_5fscl_5fsecure_5fno_5fwarnings',['_SCL_SECURE_NO_WARNINGS',['../common_8h.html#abd0a75654ea98e87fa73a854b3f54837',1,'common.h']]]
];
