var searchData=
[
  ['rounding_5fmode',['rounding_mode',['../namespacecl_1_1sycl.html#a16ab217f4d07c904f763adf0a270d1c0',1,'cl::sycl']]]
];
