var searchData=
[
  ['partition_5faffinity_5fdomain',['partition_affinity_domain',['../namespacecl_1_1sycl_1_1info.html#aea3b7860826830db91022d3cc985119f',1,'cl::sycl::info']]],
  ['partition_5fproperty',['partition_property',['../namespacecl_1_1sycl_1_1info.html#a66692c125641cb0e2716a89739b20260',1,'cl::sycl::info']]],
  ['placeholder',['placeholder',['../namespacecl_1_1sycl_1_1access.html#af1c616691dbceeaca9cdd537a8ab0af9',1,'cl::sycl::access']]],
  ['platform',['platform',['../namespacecl_1_1sycl_1_1info.html#a3ea7e38ccbc7de5270c4f69bbae20463',1,'cl::sycl::info']]],
  ['program',['program',['../namespacecl_1_1sycl_1_1info.html#a6645cc5581516494ff2409d887258574',1,'cl::sycl::info']]],
  ['program_5fstate',['program_state',['../namespacecl_1_1sycl.html#a104e4e04504c3752e3ba5a3d4013e0eb',1,'cl::sycl']]]
];
