var searchData=
[
  ['false_5ft',['false_t',['../namespacecl_1_1sycl_1_1access.html#af1c616691dbceeaca9cdd537a8ab0af9a15f2c35ad6e5422c120ea62f6bc14366',1,'cl::sycl::access']]],
  ['fixed',['fixed',['../namespacecl_1_1sycl.html#aae8e7aa729b49299771cd464d4b17370acec315e3d0975e5cc2811d5d8725f149',1,'cl::sycl']]],
  ['fma',['fma',['../namespacecl_1_1sycl_1_1info.html#a1f763ed06ac5c82a02a7425bd7739745a8c1b768340dffcaf747fd0acc98f0ce5',1,'cl::sycl::info']]],
  ['fp16',['fp16',['../namespacecl_1_1sycl.html#aa64f3cdf8b4712806126ec95efa7d1b6a196d2105b63d84fb802c5a3a64b2f617',1,'cl::sycl::fp16()'],['../namespacecl_1_1sycl.html#a78b713c5436596506d5232e591a3b7aea196d2105b63d84fb802c5a3a64b2f617',1,'cl::sycl::fp16()']]],
  ['fp32',['fp32',['../namespacecl_1_1sycl.html#a78b713c5436596506d5232e591a3b7aea4e1bd87474ad81110395b71013094b35',1,'cl::sycl']]],
  ['fp64',['fp64',['../namespacecl_1_1sycl.html#aa64f3cdf8b4712806126ec95efa7d1b6a36dd759373a12bd5960718d0c482a2d4',1,'cl::sycl']]],
  ['function_5fname',['function_name',['../namespacecl_1_1sycl_1_1info.html#a9845a480a36d09200c5355a775fc1fa1ae82f83ed7c80ba9065e07ee379ce7a56',1,'cl::sycl::info']]]
];
