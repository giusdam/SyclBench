var searchData=
[
  ['fence_5fspace',['fence_space',['../namespacecl_1_1sycl_1_1access.html#a8cda705c3e820d7d42956d9a748482e1',1,'cl::sycl::access']]],
  ['filtering_5fmode',['filtering_mode',['../namespacecl_1_1sycl.html#a0dc52cf013f2b67be7fa2d6b0bbcdd59',1,'cl::sycl']]],
  ['fp_5fconfig',['fp_config',['../namespacecl_1_1sycl_1_1info.html#a1f763ed06ac5c82a02a7425bd7739745',1,'cl::sycl::info']]]
];
