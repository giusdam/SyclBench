var searchData=
[
  ['b',['b',['../structcl_1_1sycl_1_1elem.html#af725ee9ffa643d5b8637582f51440a0b',1,'cl::sycl::elem']]],
  ['bufferref',['bufferRef',['../classcl_1_1sycl_1_1accessor_3_01elem_t_00_01k_dims_00_01k_mode_00_01access_1_1target_1_1host__buf15cbef5585a67b9df703426df07becd.html#adbd8d5b52475953d0c19f617a988cfcd',1,'cl::sycl::accessor&lt; elemT, kDims, kMode, access::target::host_buffer, access::placeholder::false_t &gt;::bufferRef()'],['../namespacecl_1_1sycl.html#a5f84be8e0a61a63403cb7e72147da2bc',1,'cl::sycl::bufferRef()']]],
  ['bufobj',['bufObj',['../classcl_1_1sycl_1_1handler.html#ab4bdf5d8c1017daf847d2113c11242f3',1,'cl::sycl::handler']]]
];
