var searchData=
[
  ['noshowbase',['noshowbase',['../namespacecl_1_1sycl.html#a370e96d7cf28074dc0f419538bb48fb9',1,'cl::sycl']]],
  ['noshowpos',['noshowpos',['../namespacecl_1_1sycl.html#a8a6f539d6653c52997ea7026865730bb',1,'cl::sycl']]]
];
