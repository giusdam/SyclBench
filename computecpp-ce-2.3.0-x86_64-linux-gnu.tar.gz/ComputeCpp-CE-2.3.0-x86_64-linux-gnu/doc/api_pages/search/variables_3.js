var searchData=
[
  ['dec',['dec',['../namespacecl_1_1sycl.html#adb92c165d6bdd7c6cd6e6549fc38abce',1,'cl::sycl']]],
  ['defaultfloat',['defaultfloat',['../namespacecl_1_1sycl.html#aad1df7aceb30a7c7967e4f1317b9b687',1,'cl::sycl']]],
  ['destination',['destination',['../classcl_1_1sycl_1_1nd__item.html#a37f6ad8df1b7fd07285991a5e17c04aa',1,'cl::sycl::nd_item::destination()'],['../classcl_1_1sycl_1_1nd__item.html#a9d997aaf87e44e88c0a0286e38b60105',1,'cl::sycl::nd_item::destination()'],['../classcl_1_1sycl_1_1nd__item.html#a2d5a88d96b2db6117f05b3f4a95fcb8f',1,'cl::sycl::nd_item::destination()'],['../classcl_1_1sycl_1_1nd__item.html#a69742a897121515369cee7206a026d75',1,'cl::sycl::nd_item::destination()']]],
  ['dim',['dim',['../classcl_1_1sycl_1_1nd__item.html#a61ca11d24d2ce5145746a59fc328c055',1,'cl::sycl::nd_item']]],
  ['dimensions',['dimensions',['../classcl_1_1sycl_1_1buffer.html#a9ba1d043041d6e36056b71fb2ba037a8',1,'cl::sycl::buffer::dimensions()'],['../classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#ae22958fdd303c02c1dc5b2e1bca93267',1,'cl::sycl::buffer&lt; const T, dimensions, AllocatorT &gt;::dimensions()']]]
];
