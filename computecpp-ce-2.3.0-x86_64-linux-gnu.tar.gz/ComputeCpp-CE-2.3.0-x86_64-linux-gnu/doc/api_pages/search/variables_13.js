var searchData=
[
  ['z',['z',['../structcl_1_1sycl_1_1elem.html#a08274fc4fcc20507640de4dae80ef179',1,'cl::sycl::elem']]]
];
