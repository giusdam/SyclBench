var searchData=
[
  ['global',['global',['../namespacecl_1_1sycl_1_1codeplay.html#aa9503fa6c8096a10957afbcc6d36c953a9c70933aff6b2a6d08c687a6cbb6b765',1,'cl::sycl::codeplay::global()'],['../namespacecl_1_1sycl_1_1info.html#ad3cf44d11f60b23508e91d1ed61ad001a9c70933aff6b2a6d08c687a6cbb6b765',1,'cl::sycl::info::global()']]],
  ['global_5fand_5flocal',['global_and_local',['../namespacecl_1_1sycl_1_1access.html#a8cda705c3e820d7d42956d9a748482e1a78877b2c21d50a8878a02d10f4a79a3b',1,'cl::sycl::access']]],
  ['global_5fbuffer',['global_buffer',['../namespacecl_1_1sycl_1_1access.html#a6874ae9aff44c453a412c2adefb1b9f7acb1529b5988261a81704f0f39d6c287b',1,'cl::sycl::access']]],
  ['global_5fmem_5fcache_5fline_5fsize',['global_mem_cache_line_size',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5ac3f3f8fdd3d57670e960bbac3d333132',1,'cl::sycl::info']]],
  ['global_5fmem_5fcache_5fsize',['global_mem_cache_size',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a6e48f763f3d908a6200bf8f8f90bbad0',1,'cl::sycl::info']]],
  ['global_5fmem_5fcache_5ftype',['global_mem_cache_type',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a0eeabe1249684d58c7bad29611dded8a',1,'cl::sycl::info']]],
  ['global_5fmem_5fsize',['global_mem_size',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5ab4de23283932dd3379e1cf289219128c',1,'cl::sycl::info']]],
  ['global_5fspace',['global_space',['../namespacecl_1_1sycl_1_1access.html#a8cda705c3e820d7d42956d9a748482e1a8b6e19b80779e1f75b1c5f54a800dca4',1,'cl::sycl::access::global_space()'],['../namespacecl_1_1sycl_1_1access.html#a0b32461aa4a1867f288b640d7fc64fbfa8b6e19b80779e1f75b1c5f54a800dca4',1,'cl::sycl::access::global_space()']]],
  ['global_5fwork_5fsize',['global_work_size',['../namespacecl_1_1sycl_1_1info.html#a592a8baeff484e312c7f5ce6192a6ccfa408f7779a31f0760bb11cec7ace24487',1,'cl::sycl::info']]],
  ['gpu',['gpu',['../namespacecl_1_1sycl.html#aa64f3cdf8b4712806126ec95efa7d1b6a0aa0be2a866411d9ff03515227454947',1,'cl::sycl::gpu()'],['../namespacecl_1_1sycl_1_1info.html#a839771ab6b37e25ae67d5c8a2d4d97f8a0aa0be2a866411d9ff03515227454947',1,'cl::sycl::info::gpu()']]]
];
