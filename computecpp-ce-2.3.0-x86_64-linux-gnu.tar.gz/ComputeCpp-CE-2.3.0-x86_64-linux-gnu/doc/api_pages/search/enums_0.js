var searchData=
[
  ['address_5fspace',['address_space',['../namespacecl_1_1sycl_1_1access.html#a0b32461aa4a1867f288b640d7fc64fbf',1,'cl::sycl::access']]],
  ['addressing_5fmode',['addressing_mode',['../namespacecl_1_1sycl.html#a1b4377b5144c86548305fcdc66aa42df',1,'cl::sycl']]],
  ['alloc',['alloc',['../namespacecl_1_1sycl_1_1experimental_1_1usm.html#a6c249557f3c2cb3ff34bce095c8d4125',1,'cl::sycl::experimental::usm']]],
  ['aspect_5fimpl',['aspect_impl',['../namespacecl_1_1sycl.html#aa64f3cdf8b4712806126ec95efa7d1b6',1,'cl::sycl']]]
];
