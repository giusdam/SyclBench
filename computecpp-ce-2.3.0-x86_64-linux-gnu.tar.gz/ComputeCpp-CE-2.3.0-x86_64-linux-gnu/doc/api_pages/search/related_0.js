var searchData=
[
  ['add_5fexception_5fto_5flist',['add_exception_to_list',['../classcl_1_1sycl_1_1exception__list.html#a26bbfc99809bd5f255b46f4c1fcac9cd',1,'cl::sycl::exception_list']]]
];
