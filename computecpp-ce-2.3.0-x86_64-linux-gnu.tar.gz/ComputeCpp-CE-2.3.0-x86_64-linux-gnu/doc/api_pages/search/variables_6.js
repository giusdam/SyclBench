var searchData=
[
  ['g',['g',['../structcl_1_1sycl_1_1elem.html#a43b1fcb5620d37c29c0bb888c860ad40',1,'cl::sycl::elem']]]
];
