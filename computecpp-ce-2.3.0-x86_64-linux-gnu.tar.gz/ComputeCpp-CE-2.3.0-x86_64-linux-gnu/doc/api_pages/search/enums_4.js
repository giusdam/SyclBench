var searchData=
[
  ['event',['event',['../namespacecl_1_1sycl_1_1info.html#ad6dde1d8cdb42ae488540a7c276e4c56',1,'cl::sycl::info']]],
  ['event_5fcommand_5fstatus',['event_command_status',['../namespacecl_1_1sycl_1_1info.html#a475d78cf58a02b3f1abb3b1dcd144c63',1,'cl::sycl::info']]],
  ['event_5fprofiling',['event_profiling',['../namespacecl_1_1sycl_1_1info.html#a982c34d609e64bcf30c733257890f157',1,'cl::sycl::info']]],
  ['execution_5fcapability',['execution_capability',['../namespacecl_1_1sycl_1_1info.html#a325a35c99165b9ee10d88acd0ea73c00',1,'cl::sycl::info']]]
];
