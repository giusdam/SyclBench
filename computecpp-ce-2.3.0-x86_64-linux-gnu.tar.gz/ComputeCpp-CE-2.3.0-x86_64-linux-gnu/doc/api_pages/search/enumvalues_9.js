var searchData=
[
  ['l1_5fcache',['L1_cache',['../namespacecl_1_1sycl_1_1info.html#aea3b7860826830db91022d3cc985119fa84426bc33cb131aa00c40cd629ae5727',1,'cl::sycl::info']]],
  ['l2_5fcache',['L2_cache',['../namespacecl_1_1sycl_1_1info.html#aea3b7860826830db91022d3cc985119fac58e8051e3e9607bb653b0d5bcb918e7',1,'cl::sycl::info']]],
  ['l3_5fcache',['L3_cache',['../namespacecl_1_1sycl_1_1info.html#aea3b7860826830db91022d3cc985119fa4caa8fade30967a8377af50b650cdba4',1,'cl::sycl::info']]],
  ['l4_5fcache',['L4_cache',['../namespacecl_1_1sycl_1_1info.html#aea3b7860826830db91022d3cc985119fa7f52cd07191bbdfc8bf925acf7076ffd',1,'cl::sycl::info']]],
  ['linear',['linear',['../namespacecl_1_1sycl.html#a0dc52cf013f2b67be7fa2d6b0bbcdd59a9a932b3cb396238423eb2f33ec17d6aa',1,'cl::sycl']]],
  ['linked',['linked',['../namespacecl_1_1sycl.html#a104e4e04504c3752e3ba5a3d4013e0ebad48e37bc19b9fe2c72923c30fd7a4152',1,'cl::sycl']]],
  ['local',['local',['../namespacecl_1_1sycl_1_1codeplay.html#aa9503fa6c8096a10957afbcc6d36c953af5ddaf0ca7929578b408c909429f68f2',1,'cl::sycl::codeplay::local()'],['../namespacecl_1_1sycl_1_1access.html#a6874ae9aff44c453a412c2adefb1b9f7af5ddaf0ca7929578b408c909429f68f2',1,'cl::sycl::access::local()'],['../namespacecl_1_1sycl_1_1info.html#ad3cf44d11f60b23508e91d1ed61ad001af5ddaf0ca7929578b408c909429f68f2',1,'cl::sycl::info::local()']]],
  ['local_5fmem_5fsize',['local_mem_size',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a735f7e0da765dcc1dfc4d3454a9aba14',1,'cl::sycl::info']]],
  ['local_5fmem_5ftype',['local_mem_type',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a65f9a150cd584ee5dd60ce5450b93ebd',1,'cl::sycl::info']]],
  ['local_5fsize_5ffor_5fsub_5fgroup_5fcount',['local_size_for_sub_group_count',['../namespacecl_1_1sycl_1_1info.html#aaee38a765a8d99422ac3d2bbd4a79b8ea4682feaf957f80eb551bd20ad46a5bd6',1,'cl::sycl::info']]],
  ['local_5fspace',['local_space',['../namespacecl_1_1sycl_1_1access.html#a8cda705c3e820d7d42956d9a748482e1a619fb1f3a892c810ac284e01782c8531',1,'cl::sycl::access::local_space()'],['../namespacecl_1_1sycl_1_1access.html#a0b32461aa4a1867f288b640d7fc64fbfa619fb1f3a892c810ac284e01782c8531',1,'cl::sycl::access::local_space()']]],
  ['luminance',['luminance',['../namespacecl_1_1sycl.html#a8557ea72c6739001cf30a301567cf3dfaf211946e6417f327f86f921b2845d54e',1,'cl::sycl']]]
];
