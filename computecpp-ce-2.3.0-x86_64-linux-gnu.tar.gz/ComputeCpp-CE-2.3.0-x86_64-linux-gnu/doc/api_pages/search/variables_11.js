var searchData=
[
  ['x',['x',['../structcl_1_1sycl_1_1elem.html#a089abc6a7d823616e5091e5ff293f088',1,'cl::sycl::elem']]]
];
