var searchData=
[
  ['exception_5fptr_5fclass',['exception_ptr_class',['../namespacecl_1_1sycl.html#a2142f5990bff9e140a51aac753244d37',1,'cl::sycl']]]
];
