var searchData=
[
  ['original_5ftype_5fcref',['original_type_cref',['../classcl_1_1sycl_1_1multi__ptr.html#a7cbc9eb8dbcc3c47f32fdbb670cf53c2',1,'cl::sycl::multi_ptr']]],
  ['original_5ftype_5fref',['original_type_ref',['../classcl_1_1sycl_1_1multi__ptr.html#a1bed04e4e4ae8ce4ac08c568b6c83780',1,'cl::sycl::multi_ptr']]],
  ['other',['other',['../structcl_1_1sycl_1_1experimental_1_1usm__allocator_1_1rebind.html#ab6442ee46fdbc8930ead656a686d5b55',1,'cl::sycl::experimental::usm_allocator::rebind']]]
];
