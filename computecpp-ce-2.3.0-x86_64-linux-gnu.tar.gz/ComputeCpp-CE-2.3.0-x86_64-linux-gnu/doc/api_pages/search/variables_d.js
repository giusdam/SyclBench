var searchData=
[
  ['oct',['oct',['../namespacecl_1_1sycl.html#a03bfa43c64b66e8ad041a2bc79a9991a',1,'cl::sycl']]],
  ['offset',['offset',['../classcl_1_1sycl_1_1nd__item.html#a49c8dfed27884eec02680dd361312933',1,'cl::sycl::nd_item::offset()'],['../classcl_1_1sycl_1_1nd__item.html#a9790764057f4a926e92391786fdb3ea7',1,'cl::sycl::nd_item::offset()'],['../classcl_1_1sycl_1_1nd__item.html#a9faad353938bdaefebeeeaa01d69d54c',1,'cl::sycl::nd_item::offset()'],['../classcl_1_1sycl_1_1nd__item.html#a8cf66c601c223bbd7f9df64e23d3fddb',1,'cl::sycl::nd_item::offset()']]]
];
