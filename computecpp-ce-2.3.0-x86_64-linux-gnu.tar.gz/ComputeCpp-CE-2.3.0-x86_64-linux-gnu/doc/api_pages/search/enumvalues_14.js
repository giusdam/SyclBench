var searchData=
[
  ['work_5fgroup_5fsize',['work_group_size',['../namespacecl_1_1sycl_1_1info.html#a592a8baeff484e312c7f5ce6192a6ccfafffb71c6a8897dd2d01f9c13ef174cb4',1,'cl::sycl::info']]],
  ['write',['write',['../namespacecl_1_1sycl_1_1codeplay.html#aa647be847f5f30d9ea39f4a6a2e8cb6eaefb2a684e4afb7d55e6147fbe5a332ee',1,'cl::sycl::codeplay::write()'],['../namespacecl_1_1sycl_1_1access.html#ade7472cc9b6db9b3cd47fb9f3bc8c450aefb2a684e4afb7d55e6147fbe5a332ee',1,'cl::sycl::access::write()']]]
];
