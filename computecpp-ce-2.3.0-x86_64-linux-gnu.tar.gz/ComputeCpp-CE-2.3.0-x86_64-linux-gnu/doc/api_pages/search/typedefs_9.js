var searchData=
[
  ['local_5fptr',['local_ptr',['../namespacecl_1_1sycl.html#a1cc7492051b5b987a7da402f12735a84',1,'cl::sycl']]],
  ['logical_5fand',['logical_and',['../namespacecl_1_1sycl_1_1experimental.html#aac87dba5001716193dd9c6030eb2a978',1,'cl::sycl::experimental']]],
  ['logical_5for',['logical_or',['../namespacecl_1_1sycl_1_1experimental.html#a6475b81612e732326155622ffca9592d',1,'cl::sycl::experimental']]],
  ['long16',['long16',['../namespacecl_1_1sycl.html#a93bd271e6f1045b29da404688f9caf0d',1,'cl::sycl']]],
  ['long2',['long2',['../namespacecl_1_1sycl.html#a3e0f31315dd0ba8fdd095f5a6fae68fb',1,'cl::sycl']]],
  ['long3',['long3',['../namespacecl_1_1sycl.html#a65f0d17d7c9570f383e1e1c3e1466a0e',1,'cl::sycl']]],
  ['long4',['long4',['../namespacecl_1_1sycl.html#aff9193e763dd2f5da9bc7437d89d839f',1,'cl::sycl']]],
  ['long8',['long8',['../namespacecl_1_1sycl.html#a6c8768d69620d26c7467c51a9bae158d',1,'cl::sycl']]],
  ['longlong16',['longlong16',['../namespacecl_1_1sycl.html#af947f940275342ab7bb4bdbc27661605',1,'cl::sycl']]],
  ['longlong2',['longlong2',['../namespacecl_1_1sycl.html#ac03ecc71bff44459fa4a16c955d221a3',1,'cl::sycl']]],
  ['longlong3',['longlong3',['../namespacecl_1_1sycl.html#ac7b1592ff9312b810db2cbccb80c51be',1,'cl::sycl']]],
  ['longlong4',['longlong4',['../namespacecl_1_1sycl.html#ac851ba28aec99189a338e10b68c61c8f',1,'cl::sycl']]],
  ['longlong8',['longlong8',['../namespacecl_1_1sycl.html#aeb083cf0b9b3f63686d39653e721fa31',1,'cl::sycl']]]
];
