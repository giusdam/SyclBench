var searchData=
[
  ['schar16',['schar16',['../namespacecl_1_1sycl.html#a6115eaafa8fa94077ea6d17dd6b56078',1,'cl::sycl']]],
  ['schar2',['schar2',['../namespacecl_1_1sycl.html#ae4ce07baf4ebdf0876d3b483c490c658',1,'cl::sycl']]],
  ['schar3',['schar3',['../namespacecl_1_1sycl.html#a23077992c0defcff55843c68d19d28b8',1,'cl::sycl']]],
  ['schar4',['schar4',['../namespacecl_1_1sycl.html#a55baceb6e50390c7973850b1d39fff49',1,'cl::sycl']]],
  ['schar8',['schar8',['../namespacecl_1_1sycl.html#a9dbf7ef1eade22860566ab353d9fcc90',1,'cl::sycl']]],
  ['shared_5fptr_5fclass',['shared_ptr_class',['../namespacecl_1_1sycl.html#a145741acbe1817e4b03338ffcfd21012',1,'cl::sycl']]],
  ['short16',['short16',['../namespacecl_1_1sycl.html#a14f74677134c71b1e1b8f18c14c72543',1,'cl::sycl']]],
  ['short2',['short2',['../namespacecl_1_1sycl.html#a6f895497d72f2ebfe9179587b2ca5061',1,'cl::sycl']]],
  ['short3',['short3',['../namespacecl_1_1sycl.html#a11d966a68eb77460c8d6aa9384aae9b9',1,'cl::sycl']]],
  ['short4',['short4',['../namespacecl_1_1sycl.html#ace0c68aa51a25eb8f69bf60230a1a018',1,'cl::sycl']]],
  ['short8',['short8',['../namespacecl_1_1sycl.html#abc67915fd8906d80187028543366efc7',1,'cl::sycl']]],
  ['size_5ftype',['size_type',['../classcl_1_1sycl_1_1exception__list.html#acdc3af9e05d16fa5553e0daafb026ea4',1,'cl::sycl::exception_list']]],
  ['string_5fclass',['string_class',['../namespacecl_1_1sycl.html#a20186da90261e9302b957e4823179f1b',1,'cl::sycl']]],
  ['sub_5fgroup',['sub_group',['../namespacecl_1_1sycl_1_1codeplay.html#a1a4d910bb1ed20981ec0236a9a1798ea',1,'cl::sycl::codeplay']]],
  ['subgroup_5flocal_5fptr',['subgroup_local_ptr',['../namespacecl_1_1sycl_1_1codeplay.html#ad6aa6cfd8237d3d54f0b1fdf5d6e0a5d',1,'cl::sycl::codeplay']]]
];
