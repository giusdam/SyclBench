var device__memory_8h =
[
    [ "memory_type", "device__memory_8h.html#aa9503fa6c8096a10957afbcc6d36c953", [
      [ "global", "device__memory_8h.html#aa9503fa6c8096a10957afbcc6d36c953a9c70933aff6b2a6d08c687a6cbb6b765", null ],
      [ "local", "device__memory_8h.html#aa9503fa6c8096a10957afbcc6d36c953af5ddaf0ca7929578b408c909429f68f2", null ],
      [ "onchip", "device__memory_8h.html#aa9503fa6c8096a10957afbcc6d36c953ad8df58ebf5807433cce003778ecffbea", null ]
    ] ],
    [ "get_allocated_memory_size", "device__memory_8h.html#adaafbd01dabe586076966eeb23135202", null ]
];