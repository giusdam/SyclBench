var classcl_1_1sycl_1_1exception =
[
    [ "get_cl_code", "classcl_1_1sycl_1_1exception.html#abd0499971bd5a52de8eaf99518d77f31", null ],
    [ "get_context", "classcl_1_1sycl_1_1exception.html#a759f022512adc50026e6d80f869812a0", null ],
    [ "has_context", "classcl_1_1sycl_1_1exception.html#a7597a7452826322839f2043bd131bb24", null ],
    [ "what", "classcl_1_1sycl_1_1exception.html#a33eb33409014adfca8a71555ec20a5c8", null ]
];