var usm__definitions_8h =
[
    [ "alloc", "usm__definitions_8h.html#a6c249557f3c2cb3ff34bce095c8d4125", [
      [ "host", "usm__definitions_8h.html#a6c249557f3c2cb3ff34bce095c8d4125a67b3dba8bc6778101892eb77249db32e", null ],
      [ "device", "usm__definitions_8h.html#a6c249557f3c2cb3ff34bce095c8d4125a913f9c49dcb544e2087cee284f4a00b7", null ],
      [ "shared", "usm__definitions_8h.html#a6c249557f3c2cb3ff34bce095c8d4125a9e81e7b963c71363e2fb3eefcfecfc0e", null ],
      [ "unknown", "usm__definitions_8h.html#a6c249557f3c2cb3ff34bce095c8d4125aad921d60486366258809553a3db49a4a", null ]
    ] ]
];