var NAVTREE =
[
  [ "Codeplay ComputeCpp", "index.html", [
    [ "Codeplay ComputeCpp Professional Edition", "index.html", null ],
    [ "Todo List", "todo.html", null ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", "namespacemembers_dup" ],
        [ "Functions", "namespacemembers_func.html", "namespacemembers_func" ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"classcl_1_1sycl_1_1buffer.html#a9756dbb9d4df311db59edd579f4db563",
"classcl_1_1sycl_1_1group.html#abd1d674fc1c445896cd69602f0a5ffca",
"classcl_1_1sycl_1_1multi__ptr_3_01const_01void_00_01asp_01_4.html#a4f352421f1496a614ba20dd04d363325",
"classcl_1_1sycl_1_1range_3_012_01_4.html#a9b3644bbe2159e6799106c4983d5b038",
"device__info_8h.html#a8986fcccc4479065bdbf37d9b9d8def5a06ad287ea83b37a6f9db3d8d10d72c8f",
"namespacecl_1_1sycl_1_1codeplay.html",
"structcl_1_1sycl_1_1stream__vec_3_013_00_01true_00_01element_t_00_01k_dimensions_01_4.html",
"usm_8h.html#a2d401366a92e9d8c5e13730a638c12cc"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';