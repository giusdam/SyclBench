var classcl_1_1sycl_1_1property__list =
[
    [ "property_list", "classcl_1_1sycl_1_1property__list.html#ae75fab796ceac156e45aead37e73cc65", null ],
    [ "property_list", "classcl_1_1sycl_1_1property__list.html#a397a748d89347ded7537c6249602aa04", null ]
];