var aspect_8h =
[
    [ "aspect_impl", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6", [
      [ "host", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6a67b3dba8bc6778101892eb77249db32e", null ],
      [ "cpu", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6ad9747e2da342bdb995f6389533ad1a3d", null ],
      [ "gpu", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6a0aa0be2a866411d9ff03515227454947", null ],
      [ "accelerator", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6a226522b5dff606dbd2bc2538e0d26f6c", null ],
      [ "custom", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6a8b9035807842a4e4dbe009f3f1478127", null ],
      [ "fp16", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6a196d2105b63d84fb802c5a3a64b2f617", null ],
      [ "fp64", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6a36dd759373a12bd5960718d0c482a2d4", null ],
      [ "int64_base_atomics", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6aaa6617e52aac9a99ad45d5a3aa0b60da", null ],
      [ "int64_extended_atomics", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6ac759159b1d194edcb39b140f599e0c2c", null ],
      [ "image", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6a78805a221a988e79ef3f42d7c5bfd418", null ],
      [ "online_compiler", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6ad09fec1f234c40f63b2caa649928bffd", null ],
      [ "online_linker", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6a6eac88ab4945becf3d3ddeeaee00e2a0", null ],
      [ "queue_profiling", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6acff13e821b304bffc11e5a8b52b78359", null ],
      [ "usm_device_allocations", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6aed96eac28639cadc818b197ffff31d65", null ],
      [ "usm_host_allocations", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6a1f662c5dce6a25abcb7d2c926e3a0827", null ],
      [ "usm_shared_allocations", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6a757940ac6b3936d6a82b0570ee118a7d", null ],
      [ "usm_restricted_shared_allocations", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6a220d53bc7a23df5c8f0eb7351531d191", null ],
      [ "usm_system_allocator", "aspect_8h.html#aa64f3cdf8b4712806126ec95efa7d1b6ac46b424deab98bed9ab77e13a15bef39", null ]
    ] ]
];