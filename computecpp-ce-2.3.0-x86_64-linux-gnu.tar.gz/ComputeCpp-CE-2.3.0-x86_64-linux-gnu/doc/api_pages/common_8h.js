var common_8h =
[
    [ "accessor", "classcl_1_1sycl_1_1accessor.html", null ],
    [ "_SCL_SECURE_NO_WARNINGS", "common_8h.html#abd0a75654ea98e87fa73a854b3f54837", null ],
    [ "bitset_class", "common_8h.html#a137610666a25428027b505d0b4d98fd0", null ],
    [ "byte", "common_8h.html#a8a434f950a184b3d0d3e123250c5e66a", null ],
    [ "function_class", "common_8h.html#a7550bccaabf1f69b87c288f8f69dc11e", null ],
    [ "hash_class", "common_8h.html#af2725900e89b5f8e9dbca1b104d9faa8", null ],
    [ "mutex_class", "common_8h.html#a0e818f1ac2ba5084b08dd41ca813ef28", null ],
    [ "shared_ptr_class", "common_8h.html#a145741acbe1817e4b03338ffcfd21012", null ],
    [ "string_class", "common_8h.html#a20186da90261e9302b957e4823179f1b", null ],
    [ "unique_ptr_class", "common_8h.html#a263de947d42a655f7b44b37b4774c3b9", null ],
    [ "vector_class", "common_8h.html#a0a3b58674c77d248758b6bee05800ac5", null ],
    [ "weak_ptr_class", "common_8h.html#a8cc65d5e679773a053245819fa2a13de", null ],
    [ "mode", "common_8h.html#ade7472cc9b6db9b3cd47fb9f3bc8c450", [
      [ "read", "common_8h.html#ade7472cc9b6db9b3cd47fb9f3bc8c450aecae13117d6f0584c25a9da6c8f8415e", null ],
      [ "write", "common_8h.html#ade7472cc9b6db9b3cd47fb9f3bc8c450aefb2a684e4afb7d55e6147fbe5a332ee", null ],
      [ "read_write", "common_8h.html#ade7472cc9b6db9b3cd47fb9f3bc8c450a06ad287ea83b37a6f9db3d8d10d72c8f", null ],
      [ "discard_write", "common_8h.html#ade7472cc9b6db9b3cd47fb9f3bc8c450af0d9952b32031a9b0c9606400dff53f9", null ],
      [ "discard_read_write", "common_8h.html#ade7472cc9b6db9b3cd47fb9f3bc8c450a5521dbab91d3894807c5ad7e84e14f4b", null ],
      [ "atomic", "common_8h.html#ade7472cc9b6db9b3cd47fb9f3bc8c450a23d33884d600e542d097cd3933df2ae4", null ]
    ] ],
    [ "placeholder", "common_8h.html#af1c616691dbceeaca9cdd537a8ab0af9", [
      [ "false_t", "common_8h.html#af1c616691dbceeaca9cdd537a8ab0af9a15f2c35ad6e5422c120ea62f6bc14366", null ],
      [ "true_t", "common_8h.html#af1c616691dbceeaca9cdd537a8ab0af9a1b756892a15e10bdbdfe033bf55e8d03", null ]
    ] ],
    [ "target", "common_8h.html#a6874ae9aff44c453a412c2adefb1b9f7", [
      [ "host_buffer", "common_8h.html#a6874ae9aff44c453a412c2adefb1b9f7aa0599d72026e3c6df4a0488cdf4e18d7", null ],
      [ "global_buffer", "common_8h.html#a6874ae9aff44c453a412c2adefb1b9f7acb1529b5988261a81704f0f39d6c287b", null ],
      [ "constant_buffer", "common_8h.html#a6874ae9aff44c453a412c2adefb1b9f7ade1df516592d6089a5a1d4c9280f257b", null ],
      [ "local", "common_8h.html#a6874ae9aff44c453a412c2adefb1b9f7af5ddaf0ca7929578b408c909429f68f2", null ],
      [ "host_image", "common_8h.html#a6874ae9aff44c453a412c2adefb1b9f7ad19909e3ef6decbf2453174616b470c2", null ],
      [ "image", "common_8h.html#a6874ae9aff44c453a412c2adefb1b9f7a78805a221a988e79ef3f42d7c5bfd418", null ],
      [ "image_array", "common_8h.html#a6874ae9aff44c453a412c2adefb1b9f7a2b129ecb57e9d0146c2de1fb9ef6cdd3", null ],
      [ "subgroup_local", "common_8h.html#a6874ae9aff44c453a412c2adefb1b9f7a8691eace5d3df6a9f19618963698f658", null ]
    ] ]
];