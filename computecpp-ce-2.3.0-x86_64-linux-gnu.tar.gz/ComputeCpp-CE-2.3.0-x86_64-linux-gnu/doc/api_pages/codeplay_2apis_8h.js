var codeplay_2apis_8h =
[
    [ "handler", "classcl_1_1sycl_1_1codeplay_1_1handler.html", "classcl_1_1sycl_1_1codeplay_1_1handler" ],
    [ "host_handler", "classcl_1_1sycl_1_1codeplay_1_1host__handler.html", "classcl_1_1sycl_1_1codeplay_1_1host__handler" ],
    [ "flush", "codeplay_2apis_8h.html#a12b56459e5d460461feabb6a8020d4dc", null ]
];