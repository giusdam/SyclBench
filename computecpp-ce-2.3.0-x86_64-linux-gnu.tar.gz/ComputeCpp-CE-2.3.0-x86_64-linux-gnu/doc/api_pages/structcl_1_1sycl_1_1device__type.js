var structcl_1_1sycl_1_1device__type =
[
    [ "ptr_t", "structcl_1_1sycl_1_1device__type.html#a1d0073b6309be1bc6199b4bfdb187ad4", null ],
    [ "underlying_t", "structcl_1_1sycl_1_1device__type.html#a75bd465073cb0349deaa13ab856ecfda", null ]
];