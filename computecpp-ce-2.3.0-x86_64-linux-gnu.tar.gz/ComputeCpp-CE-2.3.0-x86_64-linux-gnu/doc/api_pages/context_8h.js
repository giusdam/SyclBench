var context_8h =
[
    [ "context", "classcl_1_1sycl_1_1context.html", "classcl_1_1sycl_1_1context" ],
    [ "info_convert< cl_context *, context >", "structcl_1_1sycl_1_1info__convert_3_01cl__context_01_5_00_01context_01_4.html", null ],
    [ "hash< cl::sycl::context >", "structstd_1_1hash_3_01cl_1_1sycl_1_1context_01_4.html", "structstd_1_1hash_3_01cl_1_1sycl_1_1context_01_4" ],
    [ "gl_context_interop", "context_8h.html#a5175660b1ec299ffb370f7e8c56a5b16", null ],
    [ "context", "context_8h.html#a1a5898274a448ac592ebbcee928939c1", [
      [ "reference_count", "context_8h.html#a1a5898274a448ac592ebbcee928939c1a40d852658166dc8a786c23023cb20f92", null ],
      [ "platform", "context_8h.html#a1a5898274a448ac592ebbcee928939c1a34a6e5d64ade17ef4e51612c50dd72f5", null ],
      [ "devices", "context_8h.html#a1a5898274a448ac592ebbcee928939c1ae0212e54ec3a2a120ca0d321b3a60c78", null ]
    ] ]
];