var host__access_8h =
[
    [ "host_access", "classcl_1_1sycl_1_1codeplay_1_1property_1_1buffer_1_1host__access.html", "classcl_1_1sycl_1_1codeplay_1_1property_1_1buffer_1_1host__access" ],
    [ "host_access_mode", "host__access_8h.html#aa647be847f5f30d9ea39f4a6a2e8cb6e", [
      [ "none", "host__access_8h.html#aa647be847f5f30d9ea39f4a6a2e8cb6ea334c4a4c42fdb79d7ebc3e73b517e6f8", null ],
      [ "read", "host__access_8h.html#aa647be847f5f30d9ea39f4a6a2e8cb6eaecae13117d6f0584c25a9da6c8f8415e", null ],
      [ "read_write", "host__access_8h.html#aa647be847f5f30d9ea39f4a6a2e8cb6ea06ad287ea83b37a6f9db3d8d10d72c8f", null ],
      [ "write", "host__access_8h.html#aa647be847f5f30d9ea39f4a6a2e8cb6eaefb2a684e4afb7d55e6147fbe5a332ee", null ]
    ] ]
];